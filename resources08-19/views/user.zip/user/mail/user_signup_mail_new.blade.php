<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

<!-- START HEADER/BANNER -->

		<tbody><tr>
			<td align="center">
				<table class="col-600" width="600" border="0" align="center" cellpadding="0" cellspacing="0">
					<tbody><tr>
						<td align="center" valign="top">
							<table class="col-600" width="600" height="auto" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color: #d0f2cf;">

								<tbody><tr>
									<td height="20"></td>
								</tr>


								<tr>
									<td align="left" style="line-height: 0px;">
										<img style="display:block; line-height:0px; font-size:0px; border:0px;padding-left: 25px;padding-bottom: 10px;" src="https://cmyqual.co.uk/assets/images/circle-logo.png" width="13%" height="auto" alt="logo">
									</td>
								</tr>



								<tr>
									<td height="5" style="background: #1D9B75;
									"></td>
								</tr>
							</tbody></table>
						</td>
					</tr>
				</tbody></table>
			</td>
		</tr>

<!-- START WHAT WE DO -->

		<tr>
			<td align="center">
				<table class="col-600" width="600" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-left:20px; margin-right:20px;">



		<tbody><tr>
			<td align="center">
				<table class="col-600" width="600" border="0" align="center" cellpadding="0" cellspacing="0" style="">
					<tbody><tr>
						<td height="15"></td>
					</tr>
					<tr>
						<td align="right">


							<table class="col2" width="287" border="0" align="right" cellpadding="0" cellspacing="0">
								<tbody><tr>
									<td align="right" style="line-height:0px;padding-right: 30px;">
										<img style="display:block; line-height:0px; font-size:0px; border:0px;margin-top: -144px;" class="images_style" src="https://cmyqual.co.uk/assets/images/template-right.png" width="auto" height="auto">
									</td>
								</tr>


							</tbody></table>






							<table width="287" border="0" align="left" cellpadding="0" cellspacing="0" class="col2" style="">
								<tbody><tr>
									<td align="center">
										<table class="insider" width="300" border="0" align="center" cellpadding="0" cellspacing="0" style="padding-left: 30px;">



											<tbody>
											<tr align="left">
												<td style="font-family: 'HammersmithOne', sans-serif; font-size:25px; color:#2a3b4c; line-height:30px; font-weight: bold;">Welcome, and great to see you here!</td>
											</tr>
											<tr>
												<td height="25"></td>
											</tr>
											<tr align="left">
												<td style="font-family: 'HammersmithOne', sans-serif; font-size:20px; color:#2a3b4c; line-height:30px; font-weight: 600;">Getting Started</td>
											</tr>
								
											<tr>
												<td height="15"></td>
											</tr>

									
											<tr>
												<td align="justify" style="font-family: 'Montserrat', sans-serif; font-size:14px; color:#2a333a; line-height:24px; font-weight: 300;">
													1. Complete your <strong>Profile.</strong> Tell us about yourself, add your skills, interests and give us some more idea of what your areas of specialism are . Don’t have all or any of your certificates? No problem, just enter all the details you have and begin to access your <strong>Achievements</strong> and <strong>My Profile</strong> pages.
													<img style="display:block; line-height:0px; font-size:0px; border:0px;margin-right: 0px;
													margin-top: -105px;
													margin-left: -45px;" class="images_style" src="https://cmyqual.co.uk/assets/images/template-broken-line.png" width="60" height="auto">
							
												</td>
											</tr>
										
									
											<tr>
												<td align="justify" style="font-family: 'Montserrat', sans-serif; font-size:14px; color:#2a333a; line-height:24px; font-weight: 300;padding-left: 0px;padding-top: 35px;padding-bottom:15px;">
													2. Set a <strong>Goal.</strong> Kickstart your target-setting and begin tracking your development journey. Would you like help? Just email us on <strong>hello@cmyqual.com</strong> to get immediate support or have a chat with a coach. We highly recommend getting a 1:1 coaching session at first to enter smarter goals. 

													<img style="
													display:block;
													line-height:0px;
													font-size:0px;
													border:0px;
													margin-right: -20px;
													margin-top: -25px;
													margin-left: 0px;
													width: 50px;
													float: right;
													" class="images_style" src="https://cmyqual.co.uk/assets/images/template-turn-right.png" width="80" height="auto">
							
												</td>
											</tr>
										

											<tr>
												<td align="justify" style="font-family: 'Montserrat', sans-serif; font-size:14px; color:#2a333a; line-height:24px; font-weight: 300;padding-left: 0px;padding-top: 0px;">
													3. Begin to track your <strong>Continuous Professional Development (CPD)</strong> hours using our tool. Use labels to tag and discover your skills gaps in professional practice through dynamic visualisations.
													
												</td>
											</tr>

											
										</tbody></table>
									</td>
								</tr>
							</tbody></table>
						</td>
					</tr>
				</tbody></table>
			</td>
		</tr>


<!-- END WHAT WE DO -->



<!-- START READY FOR NEW PROJECT -->

		<tr>
			<td align="center">
				<table align="center" width="100%" border="0" cellspacing="0" cellpadding="0" style="">
					<tbody><tr>
						<td height="50"></td>
					</tr>
					<tr>


						<td align="center">
							<table class="col-600" border="0" align="center" cellpadding="0" cellspacing="0">
								<tbody>


									<tr>

										<td width="194" height="41" style="text-align:center;white-space:nowrap;background-color:#1d9b75;height:41px;border-radius:0px;padding:0 35px 0 35px" dir="ltr">
										
										<div>
												 
										  
										<a dir="ltr" href="https://www.cmyqual.co.uk/user-login" style="color:#ffffff;display:inline-block;font-family:'Montserrat',Arial,Helvetica,sans-serif;font-size:20px;font-weight:600;height:60px;border-radius:0px;line-height:60px;text-align:center;text-decoration:none;white-space:nowrap;word-break:normal;direction:ltr;min-width:194px" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://cmyqual.co.uk/user-profile&amp;source=gmail&amp;ust=1625898818848000&amp;usg=AFQjCNHGcxaYUAC4VmIyixWzHmQmbIsKeA">Im ready - Open cMyQual</a>
										</div>
										</td>
										 </tr>

							</tbody></table>
						</td>
					</tr>
				</tbody></table>
			</td>
		</tr>


<!-- END READY FOR NEW PROJECT -->

<!-- END HEADER/BANNER -->


<!-- START 3 BOX SHOWCASE -->



		<tr>
			<td align="center">
				<table class="col-600" width="600" border="0" align="center" cellpadding="0" cellspacing="0" style="">
					<tbody><tr>
						<td height="10"></td>
					</tr>
					<tr>
						<td>


							<table class="col3" width="183" border="0" align="left" cellpadding="0" cellspacing="0">
								<tbody><tr>
									<td height="30"></td>
								</tr>
								<tr>
									<td align="center">
										<table class="insider" width="200" border="0" align="center" cellpadding="0" cellspacing="0" style="padding-left: 30px;">

											<tbody>




											<tr align="left">
												<td style="font-family: 'Raleway', Arial, sans-serif; font-size:16px; color: #212121; line-height:22px; font-weight: bold;">We’ve Planted A Tree in your name!</td>
											</tr>


											<tr>
												<td height="10"></td>
											</tr>


											<tr align="left">
												<td style="font-family: 'Montserrat', sans-serif; font-size:14px; color: #212121;; line-height:24px; font-weight: 700;"><span style="color:#1D9B75">To celebrate and as a token of thanks, we are delighted to share that for every new profile created, a tree will be planted on your behalf by</span> Sustainable Harvest International.</td>
											</tr>
											<tr>
												<td height="10"></td>
											</tr>
											<tr align="left">
												<td style="font-family: 'Montserrat', sans-serif; font-size:14px; color:#2a333a; line-height:24px; font-weight: 600;"><a href="https://www.cmyqual.co.uk/sustainability" style="color:#2a333a;background-color:#C9F8CE;padding: 5px 10px;">Learn More</a></td>
											</tr>
										</tbody></table>
									</td>
								</tr>
								<tr>
									<td height="30"></td>
								</tr>
							</tbody></table>





							<table width="1" height="20" border="0" cellpadding="0" cellspacing="0" align="left">
								<tbody><tr>
									<td height="20" style="font-size: 0;line-height: 0;border-collapse: collapse;">
										<p style="padding-left: 24px;">&nbsp;</p>
									</td>
								</tr>
							</tbody></table>



							<table class="col3" width="183" border="0" align="left" cellpadding="0" cellspacing="0">
								<tbody><tr>
									<td height="30"></td>
								</tr>
								<tr>
									<td align="center">
										<table class="insider" width="133" border="0" align="center" cellpadding="0" cellspacing="0">

											<tbody>




											<tr align="left">
												<td style="font-family: 'Montserrat', sans-serif; font-size:16px; color: #212121; line-height:22px; font-weight: bold;">Invite a friend or colleague</td>
											</tr>


											<tr>
												<td height="10"></td>
											</tr>


											<tr align="left">
													<td style="font-family: 'Montserrat', sans-serif; font-size:14px; color:#1D9B75; line-height:24px; font-weight: 700;">Would you like a friend or colleague to be a part of this? 

														Invite them to join cMyQual.</td>
											</tr>
											<tr>
												<td height="10"></td>
											</tr>
											<tr align="left">
												<td style="font-family: 'Montserrat', sans-serif; font-size:14px; color:#2a333a; line-height:24px; font-weight: 700;"><span style="color:#2a333a;background-color:#C9F8CE;padding: 5px 10px;">Invite Others</span></td>
											</tr>


										</tbody></table>
									</td>
								</tr>
								<tr>
									<td height="30"></td>
								</tr>
							</tbody></table>



							<table width="1" height="20" border="0" cellpadding="0" cellspacing="0" align="left">
								<tbody><tr>
									<td height="20" style="font-size: 0;line-height: 0;border-collapse: collapse;">
										<p style="padding-left: 24px;">&nbsp;</p>
									</td>
								</tr>
							</tbody></table>



							<table class="col3" width="183" border="0" align="right" cellpadding="0" cellspacing="0" style="padding-right: 30px;">
								<tbody><tr>
									<td height="10"></td>
								</tr>
								<tr>
									<td align="center">
										<table class="insider" width="133" border="0" align="center" cellpadding="0" cellspacing="0">

											<tbody>

											<tr align="left">
												<td style="font-family: 'Montserrat',  sans-serif; font-size:16px; color: #212121; line-height:22px; font-weight: bold;">Book a free CV Consultation</td>
											</tr>


											<tr>
												<td height="10"></td>
											</tr>


											<tr align="left">
												<td style="font-family: 'Montserrat', sans-serif; font-size:14px; color:#1D9B75; line-height:24px; font-weight: 700;">
													You also receive a free 1:1 Coaching Consultation! Here’s how</td>
											</tr>
											<tr>
												<td height="10"></td>
											</tr>
											<tr align="left">
												<td style="font-family: 'Montserrat', sans-serif; font-size:14px; color:#2a333a; line-height:24px; font-weight: 600;"><a href="mailto:hello@cmyqual.com" style="color:#2a333a;background-color:#C9F8CE;padding: 5px 10px;">Book Now</a></td>
											</tr>
										</tbody></table>
									</td>
								</tr>
								<tr>
									<td height="30"></td>
								</tr>
							</tbody></table>


						</td>
					</tr>
				</tbody></table>
			</td>
		</tr>

			<tr>
					<td height="5"></td>
		</tr>


<!-- END 3 BOX SHOWCASE -->



<!-- START FOOTER -->

		<tr>
			<td align="center">
				<table align="center" width="100%" border="0" cellspacing="0" cellpadding="0" style=" ">
					<tbody><tr>
						<td height="50"></td>
					</tr>
					<tr>
						<td align="center" bgcolor="#5CCB9A" height="100">
							<table class="col-600" width="600" border="0" align="center" cellpadding="0" cellspacing="0">
								<tbody><tr>
									<td height="25"></td>
								</tr>
								<tr>
									<td align="right" style="padding-right: 30px;font-family: 'Montserrat',  sans-serif; font-size:15px; font-weight: 600; color: #000;">Follow us on Social Media
									</td>
									</tr>
								<tr>
									<td align="left" style="padding-left: 30px;font-family: 'Montserrat',  sans-serif; font-size:12px; font-weight: 600; color: #000;">© <a href="https://cmyqual.co.uk/" style="color: #000;">cMyQual.co.uk </a>

									</td>
									</tr>
									<tr>
										<td height="10"></td>
									</tr>
									<tr>
										<td align="left" style="padding-left: 30px;font-family: 'Montserrat',  sans-serif; font-size:12px; font-weight: 600; color: #000;">You received this email because you have signed up to <br>cMyQual.co.uk with this email address</a>
	
										</td>
										</tr>
									


								<tr>
									<td height="15"></td>
								</tr>



								</tbody></table>
								
								<table align="right" width="35%" border="0" cellspacing="0" cellpadding="0" style="margin-top: -50px;">
								<tbody><tr>
									<td align="center" width="30%" style="vertical-align: top;">
											<a href="https://www.facebook.com/cMyQual" target="_blank"> <img src="https://cmyqual.co.uk/assets/images/template-fb.png" width="30"> </a>
									</td>

									<td align="center" class="margin" width="30%" style="vertical-align: top;
									padding-right: 5px;
								">
										 <a href="https://www.linkedin.com/showcase/cmyqual" target="_blank"> <img src="https://cmyqual.co.uk/assets/images/template-linkedin.png" width="30"> </a>
									</td>

									<td align="center" width="30%" style="vertical-align: top;
									padding-right: 20px;
								">
											<a href="https://www.instagram.com/cmyqual/" target="_blank"> <img src="https://cmyqual.co.uk/assets/images/template-instagram.png" width="30"> </a>
									</td>
									<td align="center" width="30%" style="vertical-align: top;    padding-right: 30px;">
										<a href="https://twitter.com/cmyqual" target="_blank"> <img src="https://cmyqual.co.uk/assets/images/template-twitter.png" width="30"> </a>
								</td>
								</tr>
								</tbody></table>



							</td></tr></tbody></table>
						</td>
					</tr>
				</tbody></table>
			</td>
		</tr>

<!-- END FOOTER -->

						
					
				</tbody></table>