<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from psdconverthtml.com/live/edupress/member-profile.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Mar 2021 09:31:30 GMT -->
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <!-- SITE META -->
    <title>CMYQUAL</title>
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keywords" content="">
    <!-- FAVICONS -->
   
    <!-- BOOTSTRAP STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/bootstrap.min.css')}}">
    <!-- TEMPLATE STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/style.css')}}">
    <!-- RESPONSIVE STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/responsive.css')}}">
    <!-- COLORS STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/colors.css')}}">
    <!-- CUSTOM STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/custom.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/validation/css/screen.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.2.3/flatpickr.css">

    <!--<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">-->

     <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<div id="divLoading"> 
</div>

<div id="divLoading2"> 
</div>

<div id="divLoading3"> 
</div>

<style>
#l_name
{
  margin: 5px 0 0px 73px;
}
  body.leftmenu #wrapper.toggled #page-content-wrapper #pwd-error, body.leftmenu #wrapper.toggled #page-content-wrapper #confirmPass-error {
    margin-left: 13% !important;
}
label#f_name-error.error
{
  margin-left: 138px !important;
}
label#studentEmailId-error.error
{
  margin-left: 138px !important;
}
.overflow-pass#pwd
{
    width: 82%;
    margin: 5px 0 0px 75px;
}
input#pwd.control.valid.validate-equalTo-blur
{
    width: 82.5%;
    margin: 5px 0 0 70px;
}
#confirmPass
{
   margin: 5px 0 0 25px;
    width: 81.5%;
   /*margin: 5px 0 0 20px;*/
   /* width: 82.5%;*/
}
.user-profile ul li input[type=email]
{
        margin: 5px 0 0px 98px;
        width: 84%;
}
.user-profile ul li input[type=text] {
    margin: 5px 0 0px 70px;
    width: 84%;
}
input#f_name.control{    margin: 5px 0 0px 68px;
    width: 84%;}
#otp{border: 1px solid rgb(25 130 98 / 55%);border-radius: 4px;
  padding: 5px 10px;
    font-size: 12px;
    width: 30%;}
    #otpModal h4
    {
      font-weight:600;
    }
    #otpModal .modal-dialog
    {
      margin: 10% auto;
    }
    .modal-header .close {
    margin-top: -40px;
}
    #otpModal .modal-header
    {
      padding: 25px 15px 15px 15px;
    }
    #otpModal .modal-footer
    {
      border-top:none;
      padding: 0px 15px 15px 15px;
    }
    #otpModal .btn
    {
    background-color: #1D9B75;
    border: none;
    color: #fff;
    border-radius: 4px;
    padding: 6px 0;
    margin: 0 auto;
    font-size: 14px;
    width: 30%;
    display: block;
    }
label.create-psw {
    padding-right: 0;
}
.create-password.user-profile input[type=text] {
    margin: 6px 0 0px 20px;
    width: 77%;
}
.create-password.user-profile #pwd-error {

    margin-left: 19% !important;
}
body.leftmenu #wrapper {
    padding-top: 69px!important;

}
body.leftmenu .sidebar-nav li
{
    margin-left:0;
}
form.cmxform label.error, label.error {
    margin-left: 130px !important;
}
 #viewpassword , #viewConpassword
{
        margin: 5px 0px 0px 0px!important;
        position: absolute!important;
       right: 45px!important;
       background: #1D9B75!important;
    color: #fff!important;
    width: 30px!important;
    height: 34px!important;
    line-height: 33px!important;
    text-align: center!important;
}

.logout-bar ul
{
        display: none;
}
input#mob-num {
    max-width: 85.85%!important;
}
.user-profile ul li input[type=password]
{
    width: 84.5%;
}
.user-profile ul li input[type=password]
{
  margin: 5px 0 0px 75px;
}
.container-fluid ul li .fa.fa-pencil-square-o
{
    right:71px;
}
.container-fluid ul li a .fa.fa-link
{
        right: 70px;
            position: absolute;
            margin: 5px 0px 0px 0px;
}
@media(max-width:414px)
{
    label#portfolio_url-error {
    margin-left: 0px !important;
}
#viewpassword
{
  margin: 32px 0px 0px 0px!important;
}
.logout-bar
{
  padding: 10px 0px;
}
.logout-bar img.img-responsive {
    margin-bottom: 0px;
}
.user-profile ul li label#f_name-error.error {
    margin-left: 0px !important;
}
.user-profile ul li label#studentEmailId-error.error {
    margin-left: 0px !important;
}
.create-password.user-profile #pwd-error {
    margin-left: 0% !important;
}
.container-fluid ul li .fa.fa-pencil-square-o
{
        margin: 31.99px 0px 0px -30px;
}
.container-fluid ul li a .fa.fa-link
{
    margin: 31px 0px 0px 0px;
}
#password ul li a .fa.fa-eye
{
    margin: 31px 0px 0px 0px;
}
#profile #select {
    width: 88.99%!important;
}
#profile ul li input[type=url] {
    width: 88.99%!important;
}
#password ul li input[type=password] {
    width: 88.5%!important;
}
}
@media(max-width:375px)
{
  .termCondition
  {
    margin-left:0px!important;
  }
  label .termCondition p {
    font-size: 10.2px!important;
}
i.cmp-notview.fa.fa-eye-slash
{
  bottom: 26%;
}
body.leftmenu #wrapper.toggled #page-content-wrapper i.cmp-notview.fa.fa-eye-slash
{
  margin-top: 32px!important;
}
}
@media(max-width:360px)
{
  i.cmp-notview.fa.fa-eye-slash
{
  margin-right: -25px!important;
}
i.cmp-notview.fa.fa-eye-slash {
    bottom: 27.5%!important;
}
}
@media(max-width:768px)
{
    form.cmxform label.error, label.error {
    margin-left: 10px !important;
}
}
@media(min-width:1920px)
{
    .error {
    padding-left: 8%!important;
}
#profile label.error {
    padding-left: 0px !important;
}
.container-fluid ul li .fa.fa-pencil-square-o, .container-fluid ul li a .fa.fa-link {
       margin-right: 9px!important;
}

.create-password.user-profile input[type=password]
{
        margin: 5px 0 0px 35px!important;
}
.create-password.user-profile select
{
    width:95%!important;
}
.create-password.user-profile #pwd-error {
    margin-left: 5% !important;
}
.create-password.user-profile input[type=text] {
    max-width: 78%!important;
}
.create-password.user-profile #confirmPass
{
    margin: 5px 0 0px 50px!important;
}
.user-profile ul li select
{
        width: 84.55%!important;
}
.create-password.user-profile ul li a .fa.fa-eye {
   
  margin-right: 29px!important;

}
.container-fluid ul li .fa.fa-pencil-square-o, .container-fluid ul li a .fa.fa-link {
  margin-right: 8px!important;
}
.user-profile ul li input[type=url]
{
        width: 82.99%!important;
}
body.leftmenu #sidebar-wrapper
{
  margin-top: 13px!important;
}
body.memberprofile .menuopener {
    margin-top: 14px!important;
    height: 50px!important;
    line-height: 50px!important;
}
}
@media(min-width:1440px)
{
    #profile .error
    {
    padding-left: 0%;
    }
    body.leftmenu #wrapper.toggled #page-content-wrapper #pwd-error, body.leftmenu #wrapper.toggled #page-content-wrapper #confirmPass-error {
    margin-left: 12% !important;
}
    .container-fluid ul li .fa.fa-pencil-square-o ,.container-fluid ul li a .fa.fa-link {
    right: 87px;
}
.user-profile ul li input[type=password] {
    width: 78.5%!important;
}
#confirmPass-error {
    margin-left: 14% !important;
}
.create-password.user-profile input[type=text] {
    margin: 6px 0 0px 20px;
    width: 82%!important;
}
.create-password.user-profile ul li a .fa.fa-eye
{
     right:65px!important;
}
}
@media(min-width:1600px)
{

    .user-profile ul li select , .user-profile ul li input[type=url]
    {
        width: 83.99%!important;
    }
    body.leftmenu #wrapper.toggled #page-content-wrapper #profile label.error {
    margin-left: 140px !important;
}
body.leftmenu #wrapper.toggled #page-content-wrapper #pwd-error, body.leftmenu #wrapper.toggled #page-content-wrapper #confirmPass-error {
    margin-left: 11% !important;
}
#profile label.error {
    margin-left: 136px !important;
}
    .container-fluid ul li .fa.fa-pencil-square-o ,.container-fluid ul li a .fa.fa-link , .create-password.user-profile ul li a .fa.fa-eye
    {
    right: 90px!important;
}
.create-password.user-profile input[type=text]
{
     width: 81%!important;
}
.user-profile ul li input[type=password]
{
    width: 78.5%!important;
}
.create-password.user-profile #pwd-error {
    margin-left: 14% !important;
}
#confirmPass-error {
    margin-left: 12% !important;
}
input#mob-num
{
        width: 88.85%!important;
}
}

@media(max-width:1024px)
{
    .user-profile ul li select, .user-profile ul li input[type=url] {
    width: 81.99%!important;
}
#l_name {
    margin: 5px 0 0px 73px!important;
}
body.leftmenu #wrapper.toggled #page-content-wrapper #pwd-error {
    margin-left: 16% !important;
}
body.leftmenu #wrapper.toggled #page-content-wrapper #confirmPass-error
{
  margin-left: 11% !important;
}
body.leftmenu #wrapper {
    padding-top: 56px!important;
}
.container-fluid ul li .fa.fa-pencil-square-o, .container-fluid ul li a .fa.fa-link, .create-password.user-profile ul li a .fa.fa-eye {
    right: 59px!important;
}
.create-password.user-profile #pwd-error {
    margin-left: 19% !important;
}
#confirmPass-error {
    padding-left: 5% !important;
}
.error {
    padding-left: 0%!important;
}
.user-profile ul li input[type=password] {
    width: 75.5%!important;
}
#pwd-error.error {
    margin-left: 21% !important;
}
input#mob-num {
    width: 84.85%!important;
}
}
@media(max-width:768px)
{
    .container-fluid ul li .fa.fa-pencil-square-o, .container-fluid ul li a .fa.fa-link, .create-password.user-profile ul li a .fa.fa-eye {
    right: 45px!important;
}
#l_name {
    margin: 5px 0 0px 15px!important;
}
body.leftmenu #wrapper.toggled #page-content-wrapper #confirmPass-error {
    margin-left: 5% !important;
}
body.leftmenu #wrapper.toggled #page-content-wrapper #pwd-error {
    margin-left: 13% !important;
}
body.leftmenu #wrapper.toggled #page-content-wrapper .overflow-pass#pwd {
  /* width: 100%!important;
    margin: 5px 0 0px 18px!important; */
    min-width: 81%!important;
    margin: 5px 0 0px 18px!important;
    }
    body.leftmenu #wrapper.toggled #page-content-wrapper #viewpassword, body.leftmenu #wrapper.toggled #page-content-wrapper #viewConpassword {
    right: 77px!important;
}
body.leftmenu #wrapper.toggled #page-content-wrapper #confirmPass {
    margin: 5px 0 0 10px!important;
    width: 69.5%!important;
}
    input#pwd.control.overflow-pass.valid
    {
      width: 74%!important;
    margin: 5px 0 0px 13px!important;
    }
    label#f_name-error.error {
    margin-left: 82px !important;
}
label#studentEmailId-error.error {
    margin-left: 78px !important;
}
form.cmxform label.error, label.error {
  margin-left: 120px !important;
    font-size: 11.5px;
}
.user-profile ul li input[type=password] {
  max-width: 72.5%!important;
}
.overflow-pass#pwd
{
  margin: 5px 0 0px 15px!important;
}
.create-password.user-profile input[type=text] {
    margin: 6px 0 0px 0px;
    width: 64%;
}
#confirmPass-error {
    padding-left: 18% !important;
}
.create-password.user-profile #pwd-error {
    margin-left: 28% !important;
}
input#mob-num {
    width: 74.85%!important;
}
}
@media(max-width:414px)
{
    .error {
    padding-left: 1%!important;
}
#l_name {
    margin: 5px 0 0px 0px!important;
}
i.cmp-notview.fa.fa-eye-slash
{
  margin-top: -32px !important;
}
body.leftmenu #wrapper.toggled #page-content-wrapper i.cmp-notview.fa.fa-eye-slash
{
  margin-top: 32px !important;
}
body.leftmenu #wrapper.toggled #page-content-wrapper .form-group label:before
{
  padding: 5.5px;
}
body.leftmenu #wrapper.toggled #page-content-wrapper .menuopener
{
  margin-top: 10px!important;
}
body.leftmenu #wrapper.toggled #page-content-wrapper .user-profile
{
    margin-left: 15%;
    margin-right: 3%;
}
body.leftmenu #wrapper.toggled #page-content-wrapper #confirmPass {
    margin: 5px 0 0 0px!important;
    min-width: 100%!important;
}
body.leftmenu #wrapper.toggled #page-content-wrapper #viewpassword, body.leftmenu #wrapper.toggled #page-content-wrapper #viewConpassword {
    margin-right: -23px!important;
}
body.leftmenu #wrapper.toggled #page-content-wrapper #pwd-error {
    margin-left: 0% !important;
}
body.leftmenu #wrapper.toggled #page-content-wrapper #confirmPass-error {
    margin-left: 0% !important;
}
.termCondition p{font-size: 12.2px!important;}
.user-profile h5
{
  margin-bottom:10px;
}
body.memberprofile .menuopener
{
  margin-top: 0px!important;
}
.user-profile ul li {
    padding: 5px 0;
}
body.dashboard-background.leftmenu #wrapper {
    padding-top: 84px!important;
}
.create-password.user-profile #pwd , .create-password.user-profile #confirmPass
{
        width: 91%;
}
label#confirmPass-error {
    padding-left: 0% !important;
   
    margin-left: 0% !important;
}
.create-password.user-profile #pwd-error {

    margin-left: 0% !important;
}
.user-profile #profile ul li input[type=password] {
    width: 100%!important;
}
input[type="submit"] , input[type="reset"]
{
    width:25%!important;
}
.user-profile ul li select, .user-profile ul li input[type=url] {
    width: 98.99%!important;
}

input#mob-num {
    width: 73.85%!important;
    margin-left: 10px;
    height: 30px;
}
.user-profile ul li select, .user-profile ul li input[type=url] {
    width: 100%!important;
}
.container-fluid ul li .fa.fa-pencil-square-o, .container-fluid ul li a .fa.fa-link, .create-password.user-profile ul li a .fa.fa-eye {
    right: 40px!important;
    margin-top: 32px;
}
}
html{scroll-behavior: smooth;}
#divLoading
{
display : none;
}
#divLoading.show
{
display : block;
position : fixed;
z-index: 100;
background-image : url('{{asset("assets/upload/loading2.gif")}}');
background-color:#666;
opacity : 0.4;
background-repeat : no-repeat;
background-position : center;
left : 0;
bottom : 0;
right : 0;
top : 0;
}
#loadinggif.show
{
left : 50%;
top : 50%;
position : absolute;
z-index : 101;
width : 32px;
height : 32px;
margin-left : -16px;
margin-top : -16px;
}
div.content {
width : 1000px;
height : 1000px;
}

#divLoading2
{
display : none;
}
#divLoading2.show
{
display : block;
position : fixed;
z-index: 100;
background-image : url('{{asset("assets/upload/loading2.gif")}}');
background-color:#666;
opacity : 0.4;
background-repeat : no-repeat;
background-position : center;
left : 0;
bottom : 0;
right : 0;
top : 0;
}

#divLoading3
{
display : none;
}
#divLoading3.show
{
display : block;
position : fixed;
z-index: 100;
background-image : url('{{asset("assets/upload/loading2.gif")}}');
background-color:#666;
opacity : 0.4;
background-repeat : no-repeat;
background-position : center;
left : 0;
bottom : 0;
right : 0;
top : 0;
}
  input[type="submit"] {
    background-color: #1D9B75;
    border: none;
    color: #fff;
    border-radius: 4px;
    padding: 6px 0;
    margin-left: 10px;
    font-size: 14px;
    width:25%;
   }
 input[type="reset"] {
    -webkit-box-sizing: content-box;
    -moz-box-sizing: content-box;
    box-sizing: content-box;
    border: 1px solid rgb(25 130 98 / 55%);
    background: transparent;
    border-radius: 4px;
    padding: 6px 0px;
    font-size: 14px;
    width:25%;
 }
 .user-profile-btn
 {
     margin-left:0;
     text-align: center;
 }
 #confirmPass-error{
  margin-left:16% !important;     
 }
 #pwd-error{
  margin-left:16% !important;     
 }
 #mob-num-error{
margin-left:120px !important;     
 }
 input#mob-num
 {
  margin: 0px 0 0px 55px;
 }
  #privacy a:hover{
  color:black !important;  
 }
 #privacy a:focus{
  color:black !important;  
 }
 #privacy a{
    color:black !important;
}
</style>
</head>
<style>
 
    html{scroll-behavior: smooth;}
    .fa-user-circle-o:before {
    content: "\f007";
}
@media(min-width:1600px)
{
  body.leftmenu #wrapper {
    padding-top: 81px!important;
}
}
.termCondition a:hover{
text-decoration:underline !important;
}
</style>

<body class="dashboard-background leftmenu memberprofile">

<div id="signup_popup" style="display:none;z-index: 999;height: 70px;
    width: 300px;
    background-color:#1D9B75;
    position: fixed;
    top: 38px;
    text-align: center;
    vertical-align: sub;
    left: 1100px;
    margin-top: 35px;
    color: #191919;">
    <p style="padding-top:20px;
    font-size: 15px;
    color: #fff !important;
    padding-left: 10px;
    font-style: oblique;">Now You Are Successfully Register</p></div>
    <!-- PRELOADER -->
    <!-- <div class="cssload-container">
        <div class="cssload-loader"></div>
    </div> -->
    <!-- end PRELOADER -->

    <!-- ******************************************
    START SITE HERE
    ********************************************** -->
    
<div class="logout-bar">
            <div class="container-fluid">
              <div class="row">
                <div class="col-lg-9 col-md-9 col-sm-6">
                <a href="{{url('')}}"><img src="{{asset('assets/images/cmyqual-logo-header.png')}}" class="img-responsive"></a>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6">
              
                </div>
              </div>
            </div>         
            </div>
 
    <div id="wrapper">
        <!-- Sidebar -->
        <div id="sidebar-wrapper">
        <a class="navbar-brand with-text"><img src="{{asset('assets/images/cmyqual-logo.png')}}" class="dashboard-logo"></a>
            <ul class="sidebar-nav">
                <li class="active"><a href="#profile">Profile <span><i class="fa fa-user"></i></span></a></li>
                <!-- <li><a href="#my-courses">My Courses <span><i class="fa fa-briefcase"></i></span></a></li> -->
              <!--   <li class="active"><a href="#password">Password <span><i class="fa fa-key" aria-hidden="true"></i></span></a></li> -->
           <!--      <li class="active"><a href="#two-factor">Two factor authentication <span><i class="fa fa-info-circle" aria-hidden="true"></i></span></a></li> -->
                <button class="back-to-sign-in"><a href="{{url('user-login')}}"><span><i class="fa fa-long-arrow-left" aria-hidden="true"></i></span> Back to Sign in</a></button>
               </ul>
        </div>
        <!-- /#sidebar-wrapper -->

        <div id="page-content-wrapper">
            <a href="#menu-toggle" class="menuopener" id="menu-toggle"><i class="fa fa-bars"></i></a>
            <div class="demo-parallax parallax section looking-photo nopadbot profile-bg" data-stellar-background-ratio="0.5" style="background-position: 0px 0px;">
                <div class="page-title section nobg nobg1">
                    <div class="container-fluid">
                        <div class="clearfix">
                            <div class="title-area pull-left">
                                <!-- <h2>My account</h2>   -->
                                <!---<small>Hello there, this is my profile.</small>--->
                            </div>
                            <!-- /.pull-right -->
                            <div class="pull-right hidden-xs">
                                <div class="bread">
                                    <ol class="breadcrumb">
                                       
                                        <li><a style="color:rgb(255 255 255 / 77%);">Setting</a></li>
                                      
                                        <li><a href="my-profile.php"><i class="fa fa-user-circle-o" aria-hidden="true"></i></a></li>
                                        <li><a href=""><i class="fa fa-bell-o" aria-hidden="true"></i></a></li>
                                        
                                    </ol>
                                </div>
                                <!-- end bread -->
                            </div>
                            <!-- /.pull-right -->
                        </div>


                        <!-- end clearfix -->
                    </div>
                </div>
                <!-- end page-title -->
             
            </div>
      
<div class="container-fluid">
<form class="form1" method="post" enctype="multipart/form-data" action="{{url('add-student')}}">
<div class="col-lg-12">
<div class="user-profile" id="profile">
<h5>Create Your Profile</h5>

<ul>
<li>
<label for="name" class=""><b>First Name<apan class="textdenger">*</apan></b></label>
<input type="text" placeholder="Enter your first name" class="control" name="f_name" id="f_name">
</li>
<li>
<label for="name" class=""><b>Last Name</b></label>
<input type="text" placeholder="Enter your last name" class="control" name="l_name" id="l_name">
</li>
<li>
<label for="email" class=""><b>Email<apan class="textdenger">*</apan></b></label>
<input type="email" id="studentEmailId" class="control" placeholder="Enter your mail" name="email" required>
</li>
{{ csrf_field() }}

<li><a href="javascript:void(0)">

    <i class="view fa fa-eye" onclick="viewpassword()" id="viewpassword" aria-hidden="true"></i>

    <i class="notview fa fa-eye-slash" style="display:none;" id="viewpassword" onclick="viewpassword()" aria-hidden="true"></i>

</a>
<label for="psw" class="create-psw"><b>Password<apan class="textdenger">*</apan></b></label>
<input type="password" class="control overflow-pass" placeholder="" id="pwd" name="psw" required>
</li>

<li><a href="javascript:void(0)">

    <i class="cmp-view fa fa-eye" onclick="cmp_viewpassword()" id="viewConpassword" aria-hidden="true"></i>

    <i class="cmp-notview fa fa-eye-slash"  style="display:none;" id="viewConpassword" onclick="cmp_viewpassword()" aria-hidden="true"></i>


</a>




<label for="psw" class=""><b>Confirm Password<apan class="textdenger">*</apan></b></label>


<input type="password" class="control" placeholder="" id="confirmPass" name="confirm_pwd" required>
</li>
<div class="round">
<div class="form-group">
            
       <input type="checkbox" checked id="javascript" name="term_condition_status" class="term-condition control-chk">

      <label for="javascript" class="termCondition" style="margin-left: 11px;margin-top: 15px;">
      <p style="display:inline;">
        <a href="{{url('terms-conditions')}}" target="_blank"  style="color:black !important;text-decoration:none;">I agree to the terms of service</a>
        and
        <a href="{{url('privacy-policy')}}" target="_blank"  style="color:black !important;text-decoration:none;">privacy policy</a>

      </p></label>
</div>
</div>
<!-- <li>
<label for="photo" class=""><b>Photo</b></label>
<span class="change-user"><i class="fa fa-user" onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])"></i></span>
<div class="fileUpload">
<input type="file" class="upload control" name="profile" accept="image/*" onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])"/>
 <span>Change</span>
</div>
<img id="blah" style="width: 62px;height:auto;border-radius: 50%;margin-left: 36px;"/>
</li> -->


<!-- <li>
<label for="dob" class=""><b>Date of Birth</b></label>
  <input type="text" name="dob" id="basicDate" placeholder="DOB" data-input>
</li> -->

<!-- <li><a href="javascript:void(0)"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
          <label for="country" class="country-dropdown"><b>Country</b></label>
          <select name="country" id="select" class="control"> 
          <option value="">-- Select Country --</option>
 @foreach($country as $countryData)
   <option value="{{$countryData->id}}">{{$countryData->country_name}}</option>
@endforeach
</select>
</li>--> 

<input type="text" name="form_id" hidden value="1"/>

<!-- <li><a href="javascript:void(0)"><i class="fa fa-link" aria-hidden="true"></i></a>
<label for="blog" class=""><b>Your Blog</b></label>
<input type="url" placeholder="nancysmith.com" name="blog_url" class="control mobile-url">
</li>

<li><a href="javascript:void(0)"><i class="fa fa-link" aria-hidden="true"></i></a>
<label for="portfolio" class="portfolio"><b>Portfolio</b></label>
<input type="url" class="control mobile-url" placeholder="nancysmith.com/portfolio" name="portfolio_url">
</li> -->



<!-- <li class="user-profile-btn">

<a href="#" class="btn cancel-btn" type="button" style="cursor:pointer;">Cancel</a>
<a href="#" class="btn save-changes" type="button" style="cursor:pointer;">Save changes</a>

</li> -->
<li class="user-profile-btn">
          <input type="reset" value="Reset">
          <input class="save-changes" id="btnSubmit" type="submit" value="Submit">
</li>
</ul>
</div>
</div>

<!-- <div class="col-lg-12">
<div class="create-password user-profile" id="password">
<h5>Create Your Password</h5>

<ul>
<li><a href="javascript:void(0)"><i class="fa fa-eye" id="viewpassword" aria-hidden="true"></i></a>
<label for="psw" class="create-psw"><b>Password</b></label>
<input type="password" class="control" placeholder="" id="pwd" name="psw" required>
</li>

<li class="psw-option">
    <p><i class="fa fa-check" aria-hidden="true"></i>Minimum 8 characters.</p>
    <p><i class="fa fa-check" aria-hidden="true"></i>At least 1 uppercase & 1 lowercase letter.</p>
    <p><i class="fa fa-check" aria-hidden="true"></i>At least 1 special character & digit.</p>
</li>

<li><a href="javascript:void(0)"><i class="fa fa-eye" id="viewConpassword" aria-hidden="true"></i></a>
<label for="psw" class=""><b>Confirm Password</b></label>
<input type="password" class="control" placeholder="" id="confirmPass" name="confirm_pwd" required>
</li>
<h5>Notification Setting</h5>
<p>
</p>
<div class="form-group">
                    <input type="checkbox" id="agree" class="notification-setting
 control-chk">
                    <label for="agree">
cMyQual sends notifications related to security, privacy and opportunities.  You can choose to unsubscribe to any email notifications once signed in.
</label>
</div>
<input type="text" name="form_id" hidden value="2"/>
<li class="user-profile-btn">
</li>
</ul>

</div>
</div>
 -->

<!-- <div class="col-lg-12">
<div class="create-password user-profile" id="two-factor">
<h5>Two factor authentication </h5>

<ul>
<div class="round">
    <br> 
    <div class="form-group">
      <input type="checkbox" id="html" name="email_confirm_status" class="email-authentication control-chk">
      <label for="html">VIA Email</label>
    </div>
   
   <input type="text" name="form_id" hidden value="3"/>
</div>
<div class="mobi-num">
<label for="number" class="mob-num"><b>Mobile No</b></label>
    <input type="text" placeholder="" id="mob-num" name="contact_no"  class="control">
</div>
<div class="hear">
                <p>Where did you hear about CMyQual?</p>
               <select id="select" class="control" name="why_like_cmyquals" class="why_cho_drop">
                    <option value="">Select - Optional</option>
                    <option value="google">Google</option>
                    <option value="career service team">Career Services Team</option>
                    <option value="lecture">University Lecture</option>
                    <option value="website">University Website</option>
                    <option value="facebook">Facebook</option>
                    <option value="linkedin">Linkedin</option>
                    <option value="other">Others</option>
                  </select>
</div>
<div class="round">
<div class="form-group">
            
       <input type="checkbox" id="javascript" name="term_condition_status" class="term-condition control-chk">
      <label for="javascript">I agree to the terms of service and privacy policy</label>
</div>
</div>
<li class="user-profile-btn">
    
       <input type="reset" value="Reset" id="btnreset">
       <input class="save-changes" name="btnsubmit" type="submit" value="Submit">
</li>
</ul>
</div>
</div> -->

</form>
</div>      
</div>
 <!-- The Modal -->
 <div class="modal fade" id="otpModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
        <h4 class="modal-title text-center">Verify Your Email</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body text-center">
        <input type="number" class="control otpSignUP" placeholder="Enter Verification Code" id="otp" name="psw" required>
        <p style="font-style:italic;display:block;">*Please check the provided email account, you will receive the verification code within 2 minutes.</p>
        <a href="javascript:void(0)" style="display:block;margin:5px 0 -5px 0px;color: #1d9b75;font-style:italic;text-decoration: underline;" onclick="resendOTP()">Resend Verification Code</a>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer text-center">
        <button type="button" class="btn" id="btnChekOtpAtSignUP" onclick="btnChekOtpAtSignUP()">Submit</button>
        </div>
        
      </div>
    </div>
  </div>
    <!-- end wrapper -->

    <!-- ******************************************
    /END SITE
    ********************************************** -->

    <!-- ******************************************
    DEFAULT JAVASCRIPT FILES
    ********************************************** -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.2.3/flatpickr.js"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js'></script>
    <script src="{{asset('assets/js/all.js')}}"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/easy-pie-chart/2.1.6/jquery.easypiechart.min.js'></script>
    <script src="{{asset('assets/js/custom.js')}}"></script>
    <script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
    <!--<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>-->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.2.3/flatpickr.js"></script>
    <script>
    
$("#basicDate").flatpickr({
    dateFormat: "d/m/Y",
    maxDate: new Date(),
});

</script>
  <script>
    
$('#btnreset').on('click',function(){

$('#blah').attr('src','');
});

function viewpassword(){
if($('#pwd').attr('type')=='password'){
$('#pwd').attr('type','text');
$('.view').hide();
$('.notview').show();
}else{
$('#pwd').attr('type','password');
$('.view').show();
$('.notview').hide();
}
}

function cmp_viewpassword(){

if($('#confirmPass').attr('type')=='password'){
$('#confirmPass').attr('type','text');
$('.cmp-view').hide();
$('.cmp-notview').show();
}else{
$('#confirmPass').attr('type','password');
$('.cmp-view').show();
$('.cmp-notview').hide();
}
}


        $(window).scroll(function() {
    var windscroll = $(window).scrollTop();
    if (windscroll >= 100) {
      $('#sidebar-wrapper').each(function(i) {
        // The number at the end of the next line is how pany pixels you from the top you want it to activate.
        if ($(this).position().top <= windscroll - 0) {
          $('ul.sidebar-nav li.active').removeClass('active');
          $('ul.sidebar-nav li').eq(i).addClass('active');
        }
      });

    } else {

      $('ul.sidebar-nav li.active').removeClass('active');
      $('ul.sidebar-nav li:first').addClass('active');
    }

    }).scroll();
    </script>
    <script type="text/javascript">

// $.validator.addMethod("regx", function(value, element, regexpr){          
//     return regexpr.test(value);
// }, "Please enter a valid password.");

$('.form1').validate({

 rules:{
  f_name:{
   required:true,
   minlength:2, 
   maxlength:30,   
  },
  l_name:{
   minlength:2, 
   maxlength:30,   
  },
  email:{
   required:true,
   maxlength:100,
   email:true,
   remote:{
   url: "<?php echo url('check-student-email');?>",
   type: "post",
   data:{emailId:$('#studentEmailId').val(),"_token":'{{csrf_token()}}'},
          }
  },
  profile:{
maxlength:500,
  },
  dob:{
 //  required:true,
  },
  country:{
 // required:true,
  },
  blog_url:{
maxlength:500,
  url:true,
  }, 
  portfolio_url:{
maxlength:500,
  url:true,
  }, 
 psw:{
required:true,
minlength:8,
maxlength:15,
//regx: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
},
confirm_pwd:{
 equalTo: "#pwd"
},
    contact_no:{
  //  required:true,
    minlength:10,
    maxlength:15,
    remote:{
    url: "<?php echo url('check-student-contactno');?>",
    type: "post",
    data:{mobile:$('#mob-num').val(),"_token":'{{csrf_token()}}'},
            }  
    }
 },
 messages:{
  f_name:{
   required:'Please enter first name',
  },
  l_name:{
  
  },
   email:{
   required:'Please enter email id',
   remote:'This email ID already exists. Please enter another one.',
   },
   profile:{
 
   },
   dob:{
   required:'Please enter valid DOB',
   min:'Pleae enter valid date',
   }, 
   country:{
   //required:'Please select country',
   },
   blog_url:{
     
   },
   portfolio_url:{
        
   },
   psw:{
  // required:'Please enter password',
   minlength:'The password must contain 8-15 character',
   maxlength:'The password must contain 8-15 character',
   },
   confirm_pwd:{
   required:'Please enter confirm password',       
   equalTo:'Password & confirm password do not match',
   },
   contact_no:{
   required:'Please enter contact no',
   remote:'This contact no already exists. Please enter another one.',
   }   
   }
});
 

$('#btnSubmit').on('click',function(){
 var email=''   
if($('.form1').valid()){
$('#otpModal').modal('show');
email=$('#studentEmailId').val();
f_name=$('#f_name').val();
l_name=$('#l_name').val();
pwd=$('#pwd').val();

$.ajax({
url:'{{url("verify-send-email-otp")}}',
method:'POST',
data:{f_name:f_name,l_name:l_name,pwd:pwd,email:email,'_token':"{{csrf_token()}}"},
success:function(data){
console.log(data);
    }
    })
return false;
}
});


function resendOTP(){
var email=$('#studentEmailId').val();
$.ajax({
url:'{{url("resend-otp")}}',
method:'POST',
data:{email:email,'_token':"{{csrf_token()}}"},
success:function(data){
console.log(data);
    }
    })
}

function btnChekOtpAtSignUP(){
var otp=$('.otpSignUP').val();
$('#verifyMSG').show();
$.ajax({
url:'{{url("user-signup-at-email-verification")}}',
method:'POST',
data:{otp:otp,'_token':"{{csrf_token()}}"},
success:function(data){
if(data==401){
alert('Please enter valid verification code');    
}else{
window.location.href="{{url('user/edit-profile')}}";
    }
    }
    })
}


    $(function() {
    $('.chart').easyPieChart({
      size: 115,
      barColor: "#fff",
      scaleLength: 0,
      lineWidth: 8,
      trackColor: "#3333",
      lineCap: "circle",
      animate: 2000,
    });
  });
    </script>
    
<script>
window.chartColors = {
  red: 'transparent',
  orange: 'tranparent',
//   yellow: 'rgb(255, 205, 86)',
  green: 'rgb(75, 192, 192)',
  blue: '#fff',
//   purple: 'rgb(153, 102, 255)',
//   grey: 'rgb(231,233,237)'
};

var randomScalingFactor = function() {
  return (Math.random() > 0.5 ? 1.0 : 1.0) * Math.round(Math.random() * 25);
};

var line1 = [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), ];

var line2 = [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), ];

var MONTHS = ["1/3", "8/3", "15/3", "22/5"]; //"May", "June", "July", "August", "September", "October", "November", "December"
var config = {
  type: 'line',
  data: {
    labels: MONTHS,
    datasets: [{
      label: "",
      backgroundColor: window.chartColors.red,
      borderColor: window.chartColors.red,
      data: line1,
      fill: false,
    }, {
      label: "",
      fill: false,
      backgroundColor: window.chartColors.blue,
      borderColor: window.chartColors.blue,
      data: line2,
    }]
  },
  options: {
    responsive: true,
    title:{
      display:true,
      text:''
    },
    tooltips: {
      mode: 'index',
      intersect: false,
    },
   hover: {
      mode: 'nearest',
      intersect: true
    },
    scales: {
      xAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: ''
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
        },
      }]
    }
  }
};

var ctx = document.getElementById("canvas").getContext("2d");
var myLine = new Chart(ctx, config);

var data1 = [
  randomScalingFactor(),
  randomScalingFactor(),
];

// var data2 = [
//   randomScalingFactor(),
//   randomScalingFactor(),
// ];

var ctx = document.getElementById("chart-area").getContext("2d");
var myPie = new Chart(ctx, {
  type: 'pie',
  data: {
        labels: ["FTE", "FTC"],
    datasets: [{
      label: 'Dataset 1',
      data: data1,
      backgroundColor: [
        "",
        ""
      ],
      hoverBackgroundColor: [
        "",
        ""
      ],
      borderWidth: 5,
    }, {
      label: 'Dataset 2',
      data: data2,
      backgroundColor: [
        "",
        ""
      ],
      hoverBackgroundColor: [
        "",
        ""
      ],
      borderWidth: 5,
    }],
  },
  options: {
    title: {
      display: true,
      text: 'Employee Overview',
      fontStyle: 'bold',
      fontSize: 20
    }
  }
});


  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
    }
  };

/*
$('a[href="#pie"]').on('shown.bs.tab', function(){
  myPie.update();
});
*/
</script>
</body>


</html>