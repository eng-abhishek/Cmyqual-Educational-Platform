<!DOCTYPE html>
<html lang="en">
<head>
  <title>PDF</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<style>
    h1{font-size: 25px;}
    body
    {
    background-image: url(https://cmyqual.co.uk/assets/images/supercharge-bg.png);
    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
    }
.container
{
    background-color: #fff;
    box-shadow: 0 0.5rem 2rem rgb(0 0 0 / 18%);
    padding: 10px 40px 10px 40px;
}
.table thead th  {
    vertical-align: bottom;
    border-bottom: 1px solid rgb(0 0 0 / 33%);
}
.table-bordered td, .table-bordered th
{
    border: 1px solid rgb(0 0 0 / 33%);
}
.table-bordered thead td, .table-bordered thead th {
    border-bottom-width: 1px;
}
img{width: 13%;}
</style>
<body>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <img src="https://cmyqual.co.uk/assets/images/cmyqual-logo-header.png" alt="">
        </div>
        <div class="col-lg-12">
            <h1 class="text-center">Achievement</h1>
        </div>
        <div class="col-lg-12 pt-3">
            <table class="table table-bordered">
                <thead>
                  <tr>
                    <th>Achievement Name</th>
                    <td>Financial Regulations</td>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Issue On</th>
                    <td>June-2021</td>
                  </tr>
                  <tr>
                    <th>Issued By</th>
                    <td>Coursera</td>
                  </tr>
                </tbody>
                <thead>
                    <tr>
                      <th>Achievement Name</th>
                      <td>Financial Regulations</td>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th>Issue On</th>
                      <td>July-2021</td>
                    </tr>
                    <tr>
                      <th>Issued By</th>
                      <td>Coursera</td>
                    </tr>
                  </tbody>
              </table>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="text-center">Shared List</h1>
        </div>
        <div class="col-lg-12 pt-3">
            <table class="table table-bordered">
                <thead>
                  <tr>
                    <th>Name of Company</th>
                    <td>Quantum IT Innovation</td>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th>Email</th>
                    <td>ansari@gmail.ocm</td>
                  </tr>
                  <tr>
                    <th>Invite</th>
                    <td>2</td>
                  </tr>
                  <tr>
                    
                    <th>Expire Days</th>
                    <td>10</td>
                  </tr>
                </tbody>
                <thead>
                    <tr>
                      <th>Name of Company</th>
                      <td>Quantum IT Innovation</td>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th>Email</th>
                      <td>ansari@gmail.ocm</td>
                    </tr>
                    <tr>
                      <th>Invite</th>
                      <td>2</td>
                    </tr>
                    <tr>
                      
                      <th>Expire Days</th>
                      <td>10</td>
                    </tr>
                  </tbody>
              </table>
        </div>
    </div>
</div>
</body>
</html>