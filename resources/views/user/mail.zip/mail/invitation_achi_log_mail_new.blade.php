<table role="Presentation" id="m_5980372933020119328table-parent" style="background-color:#ffffff;border:0 none;border-collapse:collapse" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" width="100%">
            <tbody>
               <tr>
                  <td id="m_5980372933020119328td-parent" style="border-collapse:collapse;font-family:'Roboto',Arial,Helvetica,sans-serif;padding:0" align="center" bgcolor="#ffffff">
                     
                              <div id="m_5980372933020119328email" style="background-color:#ffffff;margin:0 auto;padding:0px 10px" bgcolor="#ffffff">
                                 <table role="Presentation" align="center" style="background-color:#f1f3f4;border-collapse:collapse;margin:0;min-width:600px;max-width:600px;width:600px;padding:0;border:1px solid #1d9b75!important" bgcolor="#f1f3f4" border="0" cellpadding="0" cellspacing="0" width="600">
<tbody>
<tr>
<td style="border-collapse:collapse;font-family:'Roboto',Arial,Helvetica,sans-serif;padding:0;background-color:#ffffff">
<table role="Presentation" style="width:600px;border:0 none;border-collapse:collapse" border="0" cellpadding="0" cellspacing="0" width="600">
<tbody>
<tr>
  
 <td style="Margin-top:0;Margin-bottom:0;Margin-right:0;Margin-left:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0">
<table role="Presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100%">
   <tbody><tr>
      <td style="Margin-top:0;Margin-bottom:0;Margin-right:0;Margin-left:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0">
        <table role="Presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100%">
          <tbody><tr>
            <td style="Margin-top:0;Margin-bottom:0;Margin-right:0;Margin-left:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:40px;max-width:40px" width="40">&nbsp;</td>
            <td style="Margin-top:0;Margin-bottom:0;Margin-right:0;Margin-left:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0">
              <table role="Presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100%">
                <tbody><tr>
                  <td style="Margin-top:0;Margin-bottom:0;Margin-right:0;Margin-left:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;height:28px;line-height:28px;font-size:0px" height="28">&nbsp;</td>
                </tr>
                <tr>
                  <td style="Margin-top:0;Margin-bottom:0;Margin-right:0;Margin-left:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;direction:ltr">
                    <table role="Presentation" width="100%" cellpadding="0" cellspacing="0" style="width:100%">
                      <tbody><tr>
                        <td style="Margin-top:0;Margin-bottom:0;Margin-right:0;Margin-left:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;text-align:left" align="left">
                          <img src="http://quantumits.online/cmyquals_backend/public/assets/images/cmyqual-logo-header.png" width="auto" height="50px" style="outline:none;text-decoration:none;display:block!important;margin:0 auto" class="CToWUd">
                        </td>
                       
                      </tr>
                    </tbody></table>
                  </td>
                </tr>
                <tr>
                  <td style="Margin-top:0;Margin-bottom:0;Margin-right:0;Margin-left:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;height:28px;line-height:28px;font-size:0px;border-bottom:1px solid #1d9b75!important" height="28">&nbsp;</td>
                </tr>
              </tbody></table>
            </td>
            <td style="Margin-top:0;Margin-bottom:0;Margin-right:0;Margin-left:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;width:40px;max-width:40px" width="40">&nbsp;</td>
          </tr>
        </tbody></table>
      </td>
   </tr>

</tbody></table>
  </td>
  </tr>
<tr>
<td style="border-collapse:collapse;font-family:'Roboto',Arial,Helvetica,sans-serif;background:#f1f3f4" align="center" valign="top" width="100%">
<table role="Presentation" style="border:0 none;border-collapse:collapse" align="center" border="0" cellpadding="0" cellspacing="0" width="100%">

<tbody>
<tr>
<td style="border-collapse:collapse;font-family:'Roboto',Arial,Helvetica,sans-serif" align="center" bgcolor="#ffffff" valign="top" width="100%">
<table role="Presentation" style="border:0 none;border-collapse:collapse" border="0" cellpadding="0" cellspacing="0" width="100%">
<tbody>                                                                     <tr>
<td style="border-collapse:collapse;font-family:'Roboto',Arial,Helvetica,sans-serif;padding:25px 40px 0px 40px" width="100%">
<table role="Presentation" style="border:0 none;border-collapse:collapse" border="0" cellpadding="0" cellspacing="0" width="100%">

<tbody>
<tr>
<td dir="ltr" style="border-collapse:collapse;color:#3c4043;font-weight:600;font-family:'Google sans','Roboto',Arial,Helvetica,sans-serif;font-size:21px;line-height:42px;padding:0px 0px;padding-bottom:0px;word-break:normal;direction:ltr" align="center" width="100%">Hi !</td>
</tr>
</tbody>

<tbody>
  <tr>
  <td dir="ltr" style="border-collapse:collapse;color:#3c4043;font-weight:500;font-family:'Google sans','Roboto',Arial,Helvetica,sans-serif;font-size:21px;line-height:42px;padding:0px 0px;padding-bottom:25px;word-break:normal;direction:ltr" align="center" width="100%">{{$user_name}} just shared their cMyQual profile with you. Please click on the link below to see what they've shared.</td>
  </tr>
</tbody>

<tbody><tr>
  <td style="Margin-top:0;Margin-bottom:0;Margin-right:0;Margin-left:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;text-align:left" align="left">
    <img src="https://cmyqual.co.uk/assets/images/link-shared.png" width="200px" height="auto" style="outline:none;text-decoration:none;display:block!important;margin:0 auto" class="CToWUd">
  </td>
 
</tr>
</tbody>
<tbody>
  <tr>
  <td dir="ltr" style="border-collapse:collapse;color:#3c4043;font-weight:400;font-family:'Google sans','Roboto',Arial,Helvetica,sans-serif;font-size:16px;line-height:20px;padding:20px 0px 0 0;padding-bottom:25px;word-break:normal;direction:ltr" align="center" width="100%">Here’s how to get your own cMyQual account for free! Sign up <a href="https://www.cmyqual.co.uk/user-login">here</a></td>
  </tr>
</tbody>
</table>
</td></tr><tr>
 <td>
<table role="Presentation" style="border:0 none;width:100%;border-collapse:collapse" border="0" cellpadding="0" cellspacing="0" width="100%">
<tbody>
<tr>
  <td style="padding:20px 40px 20px 40px">
  
    <table role="Presentation" width="" border="0" cellpadding="0" cellspacing="0" align="center">
         <tbody>
             <tr>

<td width="194" height="41" style="text-align:center;white-space:nowrap;background-color:#1D9B75;height:41px;border-radius:3px;padding:0 15px 0 15px" dir="ltr">

<div>
         
  
<a dir="ltr" href="{{$link}}" style="color:#ffffff;display:inline-block;font-family:'Roboto',Arial,Helvetica,sans-serif;font-size:16px;font-weight:600;line-height:48px;text-align:center;text-decoration:none;white-space:nowrap;word-break:normal;direction:ltr;min-width:194px" target="_blank" data-saferedirecturl="">GET STARTED</a>
</div>
</td>
 </tr>
 </tbody>
  </table>
  </td>
</tr>
</tbody>
</table>
</td>
</tr>


 </tbody>
  </table>
  </td>
</tr>



<tr>
 <td>
<table role="Presentation" style="border:0 none;border-collapse:collapse;margin-top:54px" border="0" cellpadding="0" cellspacing="0">
<tbody>
  

<tr><td style="border-collapse:collapse;color:#5f6368;font-family:'Roboto',Arial,Helvetica,sans-serif;font-size:16px;text-align:left;line-height:26px;direction:ltr;padding:0px 40px 0px 40px;word-break:normal" valign="top" width="93%" dir="ltr">Portal Link - <a href="https://cmyqual.co.uk" style="color:#1D9B75">https://cmyqual.co.uk</a></td>
  
</tr></tbody>
</table>
</td>
</tr>

<tr>
<td>
<table role="Presentation" style="border:0 none;border-collapse:collapse;" border="0" cellpadding="0" cellspacing="0" width="100%">
<tbody>
<tr>
  <td dir="ltr" style="border-collapse:collapse;color:#5f6368;font-family:'Roboto',Arial,Helvetica,sans-serif;text-align:left;font-size:16px;line-height:26px;direction:ltr;padding:20px 40px 0 40px;word-break:normal" valign="top" width="93%">Regards,</td>
</tr>
<tr>
<td dir="ltr" style="border-collapse:collapse;color:#5f6368;font-family:'Roboto',Arial,Helvetica,sans-serif;font-size:16px;direction:ltr;text-align:left;line-height:26px;word-break:normal;padding:0px 0px 15px 40px;word-break:normal" width="93%"><strong>cMyQual</strong></td>
 </tr>
</tbody>
</table>
</td>
</tr>

<tr>
    <td style="border-collapse:collapse;font-family:Roboto,sans-serif;padding:30px 40px;border-top: 1px solid #1d9b75!important" align="center" bgcolor="#ffffff" valign="top" width="100%">
       <table role="Presentation" style="border:0 none;border-collapse:collapse" align="center" border="0" cellpadding="0" cellspacing="0" width="100%">
          <tbody>
             
             <tr>
               <td colspan="2" style="border-collapse:collapse;color:#444444;direction:ltr;font-size:10px;line-height:14px;padding:0 0 12px" align="center" valign="top" width="100%"><span style="color:#444444;text-decoration:none"><font><span style="color:#444444;text-decoration:none;font-family:Roboto,sans-serif">
       <span style="font-size:inherit;color:inherit;font-weight:inherit;line-height:inherit;font-family:inherit">©cMyQual</span>
    
    
 </span></font></span></td>
             </tr>
            <tr><td colspan="2" style="border-collapse:collapse;color:#444444;font-family:'Roboto',Arial,Helvetica,sans-serif;font-size:10px;direction:ltr;line-height:14px;padding:0 0 12px;padding-bottom:0;word-break:normal" align="center" valign="top" width="100%">
    
    
       <span style="font-size:inherit;color:inherit;font-weight:inherit">If you have any query, just contact to this email— <a href="mailto:hello@cMyQual.com" style="color:#1D9B75">hello@cMyQual.com</a>, we're always happy to help out.</span>
       </td></tr>
 
          </tbody>
       </table>
    </td>
 </tr>
  
   
 </tbody>
 </table>
 </div>
  
 </td>
 </tr>
 
</tbody>
</table>
</td>
</tr>

</tbody>
</table></td>
 </tr>
 </tbody>
</table>
 </td>
</tr>

                  
                          </td>
                          
                            </tr>
                            </tbody></table>
                        </td>
                      </tr>
                    </tbody></table>
                  </td>
                </tr>
                <tr>
                  <td style="Margin-top:0;Margin-bottom:0;Margin-right:0;Margin-left:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;height:25px;line-height:25px;font-size:0px;border-bottom:1px solid #1d9b75!important" height="25">&nbsp;</td>
                </tr>
              </tbody></table>
            </td>            
          </tr>
        </tbody></table>
      </td>
   </tr>
   
</tbody></table>
   </td>
  </tr>
  
</tbody></table>
</td>
 </tr>
 
</tbody>
</table>