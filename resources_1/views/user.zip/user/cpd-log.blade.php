<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- SITE META -->
    <title>CMYQUAL</title>
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keywords" content="">

    <!-- FAVICONS -->
   
    <!-- BOOTSTRAP STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/bootstrap.min.css')}}">
    <!-- TEMPLATE STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/style.css')}}">
    <!-- RESPONSIVE STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/responsive.css')}}">
    <!-- COLORS STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/colors.css')}}">
    <!-- CUSTOM STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/custom.css')}}">
    <link rel="stylesheet" href="https://sitesupply.in/assets/css/sweetalert.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<style>
    html{scroll-behavior: smooth;}
    .recent-learn
    {
      padding-top: 0px;
    padding-left: 0;
    padding-right: 0;
    }
    @media(max-width:1024px)
    {
      .new-figma-recent .col-lg-6.col-md-6.col-sm-12
      {
        height:370px;
      }
      .goals-border
      {
        margin-top:10px;
      }
      .recent-learn.cpd-table {
    margin-top: 0%;
}

    }
@media(max-width:414px)
{
  .new-figma-recent .col-lg-6.col-md-6.col-sm-12 {
    height: auto;
}
.recent-learn
{
    padding-left: 25px;
    padding-right: 15px;
}
.goals-border
{
  width: 90%;
  margin-left: 20px;
}
.team-member-name.cpd-list ul
{
  padding-left: 20px;
}
#my-profile p
{
  padding-left:20px;
}
h4.overview-drop
{
    position: absolute;
    z-index: 99;
    top: -44px;
    font-size: 14px!important;
}
h4.cpd-drop
{
    padding-left: 20px;
    padding-top: 20px;
}
.hour-logged {
    margin-top: 47%;
    margin-bottom: 0;
}
}
@media(max-width:375px)
{
  .team-member-name.cpd-list ul li
  {
    padding:5px 10px;
  }
  .team-member-name.cpd-list ul li.filter-icon
  {
    margin-left:5px;
  }
}
@media(max-width:360px)
{
  h4.overview-drop
  {
    top:-35px;
  }
}
.expDate{
    margin: 5px 0 0px 50px;
    width: 83%;
    padding: 5px 10px 5px 10px;
    background-color: #fff;
    border: 1px solid rgb(62 163 164 / 55%);
     }
#summary
{
    margin: 5px 0 0px 84px;
    width: 83%;
    padding: 9px 10px 9px 10px;
    border: none;
    background: #fff;
    font-size: 12px;
    max-height: 70px;
    border: 1px solid rgb(62 163 164 / 55%);
}     
.tag{
    margin: 5px 0 0px 15px !important;
    width: 83% !important;    
}
.error{
 border-color:#ef3f17cc !important;    
}     

</style>
<body class="dashboard-background leftmenu memberprofile">

    <!-- PRELOADER -->
    <!-- <div class="cssload-container">
        <div class="cssload-loader"></div>
    </div> -->
    <!-- end PRELOADER -->

    <!-- ******************************************
    START SITE HERE
    ********************************************** -->
         @include('user.sidebarStu') 
        <div id="wrapper">
        <!-- Sidebar -->
         @include('user.sidebar')

        <div id="page-content-wrapper">
            <a href="#menu-toggle" class="menuopener" id="menu-toggle"><i class="fa fa-bars"></i></a>
            <div class="demo-parallax parallax section looking-photo nopadbot cpd-log-bg" data-stellar-background-ratio="0.5">
                <div class="page-title section nobg">
                    <div class="container-fluid">
                        <div class="clearfix">
                            <div class="title-area pull-left">
                                <!-- <h2>My account</h2>   -->
                                <!---<small>Hello there, this is my profile.</small>--->
                            </div>
                            <!-- /.pull-right -->
                            <div class="pull-right hidden-xs">
                                <div class="bread">
                                    <ol class="breadcrumb">
                                        <li><a href="index.php"><i class="fa fa-home" aria-hidden="true"></i></a></li>
                                        <li><a href="my-profile.php">My Profile</a></li>
                                        <li><a href="cpd-log.php">CPD Log</a></li>
                                        <!-- <li><a href="">Unfiled Organization</a></li> -->
                                    </ol>
                                </div>
                                <!-- end bread -->
                            </div>
                            <!-- /.pull-right -->
                        </div>
                        <!-- end clearfix -->
                    </div>
                </div>
                <!-- end page-title -->
            </div>

            <div class="section" id="my-profile">
                <div class="container-fluid">
                    <div class="row">
                    

                        <div class="col-md-12 col-sm-12">
                            <div class="about-widget clearfix">
                                <div class="widget-title">
                                    <!-- <h1 class="heading1">My Profile</h1> -->
                                   
                                </div><!-- end title -->
                                <div class="row">
                                    
                                  

                                    <div class="col-md-12 col-sm-12">
                                        <div class="team-member-name cpd-list">
                                        <h4 class="cpd-drop">CPD Logs</h4>
                                        <p>Including skills learned , tracking of hours</p>
                                        <ul>
                                           <li>
                                           <i class="fa fa-calendar-o" aria-hidden="true"></i> Custom
                                           </li>
                                           <li class="active">
                                               30 Days
                                           </li>
                                           <li>
                                               3 Months
                                           </li>
                                           <li>
                                               6 Months
                                           </li>
                                           <li class="filter-icon">
                                           <i class="fa fa-filter" aria-hidden="true"></i>
                                           </li>
                                       </ul>
                                        </div>
                               
                                        <!-- <hr class="invis"> -->

                   

                                    </div><!-- end col -->
                                    <!-- <div class="col-lg-12">
                                    
                                    </div> -->

<div class="col-lg-12 new-figma-recent">

    <div class="col-lg-6 col-md-6 col-sm-12">
    <h4 class="overview-drop"><i class="fa fa-caret-down" aria-hidden="true"></i>  Overview</h4>
    <div class="hour-logged">
      <span><h4>32 hours logged in past 30 days</h4></span>
      
      <span class="hour-logged"><span>+34%</span> from previous period </span>
      <div class="line-chart">
        <canvas id="canvas"></canvas>
      </div>
  </div>
    </div>
<div class="col-lg-6 col-md-6 col-sm-12">
<h4>Tags</h4>
<div id="chartContainer" style="height: 300px; width: 100%; margin: 0px auto;">

</div>
</div>
</div>
<div class="col-lg-12 goals-border">
<div class="col-lg-9 col-md-9 col-sm-6 col-xs-6">
<span class="all-goal">Your CPD Logs</span>
</div>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
<div class="add-new-box add-new-box1" type="button" data-toggle="modal" data-target="#myModal" style="cursor:pointer;">
    <span>Add New +</span>
</div>
</div>
</div>



    <div class="col-lg-12 recent-learn cpd-table">
  
    <div class="table-responsive">                
    <table class="table table-bordered">
    <thead>
      <tr class="bg">
        <th>Date</th>
        <th>Title</th>
        <th>Provider</th>
        <th>Standard</th>
        <th>Hours</th>
        <th>Summary</th>
        <th>Notes</th>
        <th>Tags</th>
       <th>Action</th>
      </tr>
    </thead>
    <tbody>
@foreach($cpdLogInfo as $cpdLogInfoData)
      <tr>
        <td><b>{{$cpdLogInfoData->date}}</b></td>
        <td>{{$cpdLogInfoData->title}}</td>
        <td>{{$cpdLogInfoData->providers}}</td>
        <td>{{$cpdLogInfoData->stander}}</td>
        <td>{{$cpdLogInfoData->hours}}</td>
        <td>{{$cpdLogInfoData->summary}}</td>
        <td>{{$cpdLogInfoData->notes}}</td>
        <td>{{$cpdLogInfoData->tags}}</td>
        <td><a href="javascript:void(0)" onclick="editlog({{$cpdLogInfoData->id}})"><i class="fa fa-edit" style="color:#1D9B75!important"></i></a>
        <a href="javascript:void(0)" onclick="removelog({{$cpdLogInfoData->id}})"><i class="fa fa-remove" style="color:#1D9B75!important"></i></a>
        </td>
      </tr>
@endforeach

     <!--  <tr>
        <td><b>Mon 1 March</b> <br>2021</td>
        <td>Oakhaven <br>Hospice</td>
        <td>NHS</td>
        <td>54</td>
        <td>16</td>
        <td>Routine <br>Carework</td>
        <td>Not much <br> to report</td>
        <td>Assessment <br>Inclusion</td>
     
      </tr>
      <tr>
        <td><b>Fri 10 March</b> <br>2021</td>
        <td>Oakhaven <br>Hospice</td>
        <td>NHS</td>
        <td>54</td>
        <td>24</td>
        <td>Routine <br>Carework</td>
        <td>Not much <br> to report</td>
        <td>Assessment <br>Inclusion</td>
     
      </tr>
      <tr>
      <td><b>Fri 20 March</b> <br>2021</td>
        <td>Oakhaven <br>Hospice</td>
        <td>NHS</td>
        <td>54</td>
        <td>24</td>
        <td>Routine <br>Carework</td>
        <td>Not much <br>to report</td>
        <td>Assessment <br>Inclusion</td>
       
      </tr> -->
    </tbody>
  </table>
  </div>
 </div>


                                </div><!-- end row -->      
                            </div><!-- end widget -->
                        </div><!-- end col -->

               
                    </div><!-- end row -->
                </div><!-- end container -->
            </div><!-- end section -->



  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
         
          <h4 class="modal-title modal-title1"><i class="fa fa-info-circle" aria-hidden="true"></i><span style="font-size:13px;color: #333;">CPD Log</span> Oakhaven Hospice</h4>
        </div>
        <div class="modal-body">
     
        <div class="modal-list modal-list-form">
        <form method="post" action="{{url('add-cpd-log')}}" id="cpd-log"> 
         @csrf
         <ul>

            <li>
            <label for="title" class="title"><b>Title</b></label>
            <input type="text" id="title" name="title" placeholder="Developement (max 35 min 3)" maxlength="35" minlength="3" style="margin-left: 53px;" required>
            </li>

            <li>
            <label for="date" class="cpd-date"><b>Date</b></label>
            <input type="date" id="date" class="expDate" name="date" placeholder = "dd/mm/yyyy" required>
            </li>
    
            <li>
            <label for="provider" class="provider"><b>Provider</b></label>
            <input type="text" placeholder="Organization Name (max 35 min 3)" name="provider" id="provider" required><i class="fa fa-pencil-square-o a-pencil pencil1" aria-hidden="true"></i>
           </li>
           <li>
            <label for="standard" class="provider"><b>Standard</b></label>
            <input type="text" placeholder="1 or 2 (max 3 min 1)" name="standard" id="standard" maxlength="3" minlength="1" required><i class="fa fa-pencil-square-o a-pencil pencil1" aria-hidden="true"></i>
           </li>
          
          <li>
          <label for="hour" class="cpd-hour"><b>Hours</b></label>
          <input type="number" placeholder="5 Hours (max 15 min 1)" name="hours" id="hours" maxlength="15" minlength="1" required><i class="fa fa-pencil-square-o a-pencil pencil1" aria-hidden="true"></i>
          </li>

          <li>
           <label for="sumaary" class="summary-area"><b>Summary</b></label>
           <textarea id="summary" name="summary" class="textarea" placeholder="About your log (max 350 min 20)" maxlength="350" minlength="20" required></textarea>
           </li>

           <li>
           <label for="notes" class="notes-area"><b>Notes</b></label>
           <textarea id="notes" name="notes" placeholder="Summery (max 350 min 20)" maxlength="350" minlength="20" required></textarea>
           </li>
 
          <li>
          <label for="" class="cpd-hour"><b>Tags</b></label>
          <input class="tag" type="text" placeholder="Coding (max 35 min 3)" name="tags" id="tags" maxlength="35" minlength="3" required>
          <input type="text" name="editId" id="editId" hidden>
          </li>

        </ul>
        <div class="space text-left">
            <button class="btn btn-primary" type="submit" style="cursor:pointer;background-color: #1D9B75 !important">Add Log</button>
          </div>
        </form> 
        </div>

        </div>     
      </div>
      
    </div>
  </div>


    <!-- end wrapper -->
  
    <!-- ******************************************
    /END SITE
    ********************************************** -->

    <!-- ******************************************
    DEFAULT JAVASCRIPT FILES
    ********************************************** -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js'></script>
    <script src="{{asset('assets/js/all.js')}}"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/easy-pie-chart/2.1.6/jquery.easypiechart.min.js'></script>
    <script src="{{asset('assets/js/custom.js')}}"></script>
    <script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js" class="__web-inspector-hide-shortcut__"></script>
    <script>
    
    $('#cpd-log').validate({
    errorPlacement: function(){
            return false;  // suppresses error message text
        }
});
    

window.onload = function () {
  
var chart = new CanvasJS.Chart("chartContainer", {
  animationEnabled: true,
  
  title:{
    text:""
  },
  axisX:{
    interval: 1
  },
  axisY2:{
    interlacedColor: "transparent",
    gridColor: "transparent",
    title: ""
  },
  data: [{
    type: "bar",
    name: "companies",
    axisYType: "secondary",
    color: "#014D65",
    dataPoints: [
  
      { y: 100, label: "Streaming" },
      { y: 105, label: "Stacking" },
      { y: 110, label: "Conferences" },
      { y: 120, label: "Equality and Diversity" },
      { y: 130, label: "Inclusion" },
      { y: 134, label: "Assessment - 32" }
    ]
  }]
});
chart.render();

}
</script>
    <script type="text/javascript">
    
    $(function() {
    $('.chart').easyPieChart({
      size: 115,
      barColor: "#fff",
      scaleLength: 0,
      lineWidth: 8,
      trackColor: "#3333",
      lineCap: "circle",
      animate: 2000,
    });
  });
    </script>
    
<script>
window.chartColors = {
  red: 'transparent',
  orange: 'tranparent',
//   yellow: 'rgb(255, 205, 86)',
  green: 'rgb(75, 192, 192)',
  blue: '#48B359',
//   purple: 'rgb(153, 102, 255)',
//   grey: 'rgb(231,233,237)'
};

var randomScalingFactor = function() {
  return (Math.random() > 0.5 ? 1.0 : 1.0) * Math.round(Math.random() * 25);
};

var line1 = [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), ];

var line2 = [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), ];

var MONTHS = ["Jan", "Feb", "March", "April" , "May"]; //"May", "June", "July", "August", "September", "October", "November", "December"
var config = {
  type: 'line',
  data: {
    labels: MONTHS,
    datasets: [{
      label: "",
      backgroundColor: window.chartColors.red,
      borderColor: window.chartColors.red,
      data: line1,
      fill: false,
    }, {
      label: "",
      fill: false,
      backgroundColor: window.chartColors.blue,
      borderColor: window.chartColors.blue,
      data: line2,
    }]
  },
  options: {
    responsive: true,
    title:{
      display:true,
      text:''
    },
    tooltips: {
      mode: 'index',
      intersect: false,
    },
   hover: {
      mode: 'nearest',
      intersect: true
    },
    scales: {
      xAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: ''
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
        },
      }]
    }
  }
};

var ctx = document.getElementById("canvas").getContext("2d");
var myLine = new Chart(ctx, config);

var data1 = [
  randomScalingFactor(),
  randomScalingFactor(),
];

// var data2 = [
//   randomScalingFactor(),
//   randomScalingFactor(),
// ];

var ctx = document.getElementById("chart-area").getContext("2d");
var myPie = new Chart(ctx, {
  type: 'pie',
  data: {
        labels: ["FTE", "FTC"],
    datasets: [{
      label: 'Dataset 1',
      data: data1,
      backgroundColor: [
        "",
        ""
      ],
      hoverBackgroundColor: [
        "",
        ""
      ],
      borderWidth: 5,
    }, {
      label: 'Dataset 2',
      data: data2,
      backgroundColor: [
        "",
        ""
      ],
      hoverBackgroundColor: [
        "",
        ""
      ],
      borderWidth: 5,
    }],
  },
  options: {
    title: {
      display: true,
      text: 'Employee Overview',
      fontStyle: 'bold',
      fontSize: 20
    }
  }
});

/*
$('a[href="#pie"]').on('shown.bs.tab', function(){
  myPie.update();
});
*/

function editlog(id){
   
$.ajax({
url:'{{url('getEditLogData')}}',
method:'POST',
data:{id:id,'_token':'{{csrf_token()}}'},
success:function(data){
//console.log(data);   
$('#myModal').modal('show');
$('#title').val(data.title);
$('#date').val(data.date);

$('#provider').val(data.providers);
$('#standard').val(data.stander);
$('#hours').val(data.hours);
$('#summary').val(data.summary);
$('#notes').val(data.notes);
$('#tags').val(data.tags);
$('#editId').val(data.id);

}
})
}


function removelog(id){
if(confirm('Are you sure to remove this log !')){
$.ajax({
url:'{{url('removeUserLogData')}}',
method:'POST',
data:{id:id,'_token':'{{csrf_token()}}'},    
success:function(data){
window.location.href='{{url('user/cpd-log')}}'; 
}
})
    
}else{
return false;    
} 

}
</script>
</body>


</html>