<!DOCTYPE html>
<html>
<head>
	<title> Achivement PDF</title>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
<h1 style="text-align:center;">My Achivement</h1>
<table class="table bordered" border="1" align="center" style="padding-top:20px">
<tr><td>Title</td> : <td>{{$achivementInfo->achivementName}}</td></tr>	

<tr><td>Issue Date</td> : <td>{{$achivementInfo->Issued}}</td></tr>	

<tr><td>Issue By</td> : <td>{{$achivementInfo->Issued_by}}</td></tr>	

<tr><td>Course Link</td> : <td>{{$achivementInfo->link_to_course}}</td></tr>	

<tr><td>Language</td> : <td>{{$achivementInfo->language}}</td></tr>	

<tr><td>Duration</td> : <td>{{$achivementInfo->duration}}</td></tr>	

</table>
</body>
</html>