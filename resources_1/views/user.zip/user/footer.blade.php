<footer class="copyrights">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-3">
                        <ul class="check"> 
                            <h3><img src="{{asset('assets/images/cmyqual-logo.png')}}" class="img-responsive"></h3>
                            <li><p>The place to grow your career</p></li>
                           
                        </ul><!-- end check -->
                        <div class="social-footer-icon">
                        <ul>
                                <li>
                                    <a href="https://instagram.com/cmyqual?igshid=fzworpvwnjyg"><i class="fa fa-instagram"></i></a>
                                </li>
                                <li>
                                    <a href="https://twitter.com/cmyqual?s=21"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.facebook.com/cMyQual"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div><!-- end col -->
                    <div class="col-md-6 col-sm-6">
                        <ul class="check"> 
                            <h3>Company</h3>
                            <li><a href="{{url('learner')}}">Learners</a></li>
                           <li><a href="{{url('employers')}}">Employers</a></li>
                           <li><a href="{{url('association')}}">Associations</a></li>
                           <li><a href="{{url('learning-institutions')}}">Learning institutions</a></li>
                           <li><a href="{{url('online-learning-partner')}}">Online learning Partners</a></li>
                           <li><a href="{{url('about-us')}}">About us</a></li>
                          <li><a href="{{url('sustainability')}}">Sustainability</a></li>
                        </ul>
                    </div>
                
                    <div class="col-md-3 col-sm-3">
                        <ul class="check"> 
                            <h3>Reach us</h3>
                            <li><a href="#"><i class="fa fa-envelope"></i> hello@cMyQual.com </a></li>
                           <!-- <li><a href=""><i class="fa fa-mobile"></i> +0800 800800</a></li>
                           <li><a href=""><i class="fa fa-map-marker"></i> 123 Learning Lane</a></li> -->
                        </ul><!-- end check -->
                          <ul class="check"> 
                            <h3>Our Blog</h3>
                            <li><a href="{{url('blog')}}">Blog</a></li>
                         
                        </ul><!-- end check -->
                    </div><!-- end col -->

  
                </div><!-- end row -->

                <!-- <hr> -->

                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="copylinks reserved">
                            <p>© 2021 cMyQual. All rights reserved</p>
                        </div><!-- end links -->
                    </div><!-- end col -->

                    <div class="col-md-9 col-sm-6 text-right">
                        <!-- <div class="footer-social text-right">
                            <a class="dmtop" href="#"><i class="fa fa-angle-up"></i></a>
                        </div> -->
                        <div class="reserved-list">
                         <ul>
                             <li><a href="{{url('terms-conditions')}}">Terms & Conditions |</a></li>
                             <li><a href="{{url('privacy-policy')}}">Privacy Policy |</a></li>
                    
                           <li><a href="">Sitemap |</a></li>
                             <li><a href="">Disclaimer</a></li>
                         </ul>
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </footer><!-- end copyrights -->
