<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from psdconverthtml.com/live/edupress/member-profile.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Mar 2021 09:31:30 GMT -->
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <!-- SITE META -->
    <title>CMYQUAL</title>
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keywords" content="">
    <!-- FAVICONS -->
   
    <!-- BOOTSTRAP STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/bootstrap.min.css')}}">
    <!-- TEMPLATE STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/style.css')}}">
    <!-- RESPONSIVE STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/responsive.css')}}">
    <!-- COLORS STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/colors.css')}}">
    <!-- CUSTOM STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/custom.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/validation/css/screen.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

     <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<div id="divLoading"> 
</div>

<div id="divLoading2"> 
</div>

<div id="divLoading3"> 
</div>

<style>

.create-password.user-profile input[type=text] {
    margin: 6px 0 0px 20px;
    width: 77%;
}
.create-password.user-profile #pwd-error {
    margin-left: 16% !important;
}
body.leftmenu #wrapper {
    padding-top: 61px!important;
}
body.leftmenu .sidebar-nav li
{
    margin-left:0;
}
form.cmxform label.error, label.error {
    margin-left: 110px !important;
}
.create-password.user-profile ul li a .fa.fa-eye
{
        margin: 5px 0px 0px 0px;
        position: absolute;
       right: 95px!important;
}
.logout-bar ul
{
        display: none;
}
input#mob-num {
    max-width: 85.85%!important;
}
.user-profile ul li input[type=password]
{
    width: 74.5%;
}

.container-fluid ul li .fa.fa-pencil-square-o
{
    right:71px;
}
.container-fluid ul li a .fa.fa-link
{
        right: 70px;
            position: absolute;
            margin: 5px 0px 0px 0px;
}
@media(max-width:414px)
{
    label#portfolio_url-error {
    margin-left: 0px !important;
}
.container-fluid ul li .fa.fa-pencil-square-o
{
        margin: 31.99px 0px 0px -30px;
}
.container-fluid ul li a .fa.fa-link
{
    margin: 31px 0px 0px 0px;
}
#password ul li a .fa.fa-eye
{
    margin: 31px 0px 0px 0px;
}
#profile #select {
    width: 88.99%!important;
}
#profile ul li input[type=url] {
    width: 88.99%!important;
}
#password ul li input[type=password] {
    width: 88.5%!important;
}
}
@media(max-width:768px)
{
    form.cmxform label.error, label.error {
    margin-left: 10px !important;
}
}
@media(min-width:1920px)
{
    .error {
    padding-left: 8%!important;
}
#profile label.error {
    padding-left: 0px !important;
}
.container-fluid ul li .fa.fa-pencil-square-o, .container-fluid ul li a .fa.fa-link {
       margin-right: 60px!important;
}
.create-password.user-profile ul li a .fa.fa-eye
{
    margin-right: 60px!important;
}
.create-password.user-profile input[type=password]
{
        margin: 5px 0 0px 35px!important;
}
.create-password.user-profile select
{
    width:95%!important;
}
.create-password.user-profile #pwd-error {
    margin-left: 5% !important;
}
.create-password.user-profile input[type=text] {
    max-width: 78%!important;
}
.create-password.user-profile #confirmPass
{
    margin: 5px 0 0px 50px!important;
}
.user-profile ul li select
{
        width: 84.55%!important;
}
.create-password.user-profile ul li a .fa.fa-eye {
    right: 145px!important;
}
.container-fluid ul li .fa.fa-pencil-square-o, .container-fluid ul li a .fa.fa-link {
    right: 145px!important;
}
.user-profile ul li input[type=url]
{
        width: 82.99%!important;
}
}
@media(min-width:1440px)
{
    #profile .error
    {
    padding-left: 0%;
    }
    .container-fluid ul li .fa.fa-pencil-square-o ,.container-fluid ul li a .fa.fa-link {
    right: 87px;
}
.user-profile ul li input[type=password] {
    width: 78.5%!important;
}
#confirmPass-error {
    margin-left: 14% !important;
}
.create-password.user-profile input[type=text] {
    margin: 6px 0 0px 20px;
    width: 82%!important;
}
.create-password.user-profile ul li a .fa.fa-eye
{
     right:65px!important;
}
}
@media(min-width:1600px)
{

    .user-profile ul li select , .user-profile ul li input[type=url]
    {
        width: 83.99%!important;
    }
#profile label.error {
    margin-left: 110px !important;
}
    .container-fluid ul li .fa.fa-pencil-square-o ,.container-fluid ul li a .fa.fa-link , .create-password.user-profile ul li a .fa.fa-eye
    {
    right: 90px!important;
}
.create-password.user-profile input[type=text]
{
     width: 81%!important;
}
.user-profile ul li input[type=password]
{
    width: 78.5%!important;
}
.create-password.user-profile #pwd-error {
    margin-left: 14% !important;
}
#confirmPass-error {
    margin-left: 12% !important;
}
input#mob-num
{
        width: 88.85%!important;
}
}

@media(max-width:1024px)
{
    .user-profile ul li select, .user-profile ul li input[type=url] {
    width: 81.99%!important;
}
.container-fluid ul li .fa.fa-pencil-square-o, .container-fluid ul li a .fa.fa-link, .create-password.user-profile ul li a .fa.fa-eye {
    right: 59px!important;
}
.create-password.user-profile #pwd-error {
    margin-left: 19% !important;
}
#confirmPass-error {
    padding-left: 5% !important;
}
.error {
    padding-left: 0%!important;
}
.user-profile ul li input[type=password] {
    width: 72.5%!important;
}
input#mob-num {
    width: 84.85%!important;
}
}
@media(max-width:768px)
{
    .container-fluid ul li .fa.fa-pencil-square-o, .container-fluid ul li a .fa.fa-link, .create-password.user-profile ul li a .fa.fa-eye {
    right: 45px!important;
}
form.cmxform label.error, label.error {
    margin-left: 70px !important;
}
.user-profile ul li input[type=password] {
    width: 66.5%!important;
}
.create-password.user-profile input[type=text] {
    margin: 6px 0 0px 0px;
    width: 64%;
}
#confirmPass-error {
    padding-left: 12% !important;
}
.create-password.user-profile #pwd-error {
    margin-left: 28% !important;
}
input#mob-num {
    width: 74.85%!important;
}
}
@media(max-width:414px)
{
    .error {
    padding-left: 1%!important;
}
.create-password.user-profile #pwd , .create-password.user-profile #confirmPass
{
        width: 91%;
}
label#confirmPass-error {
    padding-left: 0% !important;
   
    margin-left: 0% !important;
.create-password.user-profile #pwd-error {
    margin-left: 0% !important;
}
.user-profile ul li input[type=password] {
    width: 100%!important;
}
input[type="submit"] , input[type="reset"]
{
    width:25%!important;
}
.user-profile ul li select, .user-profile ul li input[type=url] {
    width: 98.99%!important;
}

input#mob-num {
    width: 73.85%!important;
    margin-left: 10px;
    height: 30px;
}
.user-profile ul li select, .user-profile ul li input[type=url] {
    width: 100%!important;
}
.container-fluid ul li .fa.fa-pencil-square-o, .container-fluid ul li a .fa.fa-link, .create-password.user-profile ul li a .fa.fa-eye {
    right: 40px!important;
    margin-top: 32px;
}
}
html{scroll-behavior: smooth;}
#divLoading
{
display : none;
}
#divLoading.show
{
display : block;
position : fixed;
z-index: 100;
background-image : url('{{asset("assets/upload/loading2.gif")}}');
background-color:#666;
opacity : 0.4;
background-repeat : no-repeat;
background-position : center;
left : 0;
bottom : 0;
right : 0;
top : 0;
}
#loadinggif.show
{
left : 50%;
top : 50%;
position : absolute;
z-index : 101;
width : 32px;
height : 32px;
margin-left : -16px;
margin-top : -16px;
}
div.content {
width : 1000px;
height : 1000px;
}

#divLoading2
{
display : none;
}
#divLoading2.show
{
display : block;
position : fixed;
z-index: 100;
background-image : url('{{asset("assets/upload/loading2.gif")}}');
background-color:#666;
opacity : 0.4;
background-repeat : no-repeat;
background-position : center;
left : 0;
bottom : 0;
right : 0;
top : 0;
}

#divLoading3
{
display : none;
}
#divLoading3.show
{
display : block;
position : fixed;
z-index: 100;
background-image : url('{{asset("assets/upload/loading2.gif")}}');
background-color:#666;
opacity : 0.4;
background-repeat : no-repeat;
background-position : center;
left : 0;
bottom : 0;
right : 0;
top : 0;
}
  input[type="submit"] {
    background-color: #1D9B75;
    border: none;
    color: #fff;
    border-radius: 4px;
    padding: 6px 0;
    margin-left: 10px;
    font-size: 14px;
    width:15%;
   }
 input[type="reset"] {
    -webkit-box-sizing: content-box;
    -moz-box-sizing: content-box;
    box-sizing: content-box;
    border: 1px solid rgb(25 130 98 / 55%);
    background: transparent;
    border-radius: 4px;
    padding: 6px 0px;
    font-size: 14px;
    width:15%;
 }
 .user-profile-btn
 {
     margin-left:0;
     text-align: center;
 }
 #confirmPass-error{
  margin-left:15% !important;     
 }
 #pwd-error{
  margin-left:7% !important;     
 }
 #mob-num-error{
margin-left:14px !important;     
 }
</style>
</head>
<style>
 
    html{scroll-behavior: smooth;}
    .fa-user-circle-o:before {
    content: "\f007";
}
</style>

<body class="dashboard-background leftmenu memberprofile">

<div id="signup_popup" style="display:none;z-index: 999;height: 70px;
    width: 300px;
    background-color:#1D9B75;
    position: fixed;
    top: 38px;
    text-align: center;
    vertical-align: sub;
    left: 1100px;
    margin-top: 35px;
    color: #191919;">
    <p style="padding-top:20px;
    font-size: 15px;
    color: #fff !important;
    padding-left: 10px;
    font-style: oblique;">Now You Are Successfully Register</p></div>
    <!-- PRELOADER -->
    <!-- <div class="cssload-container">
        <div class="cssload-loader"></div>
    </div> -->
    <!-- end PRELOADER -->

    <!-- ******************************************
    START SITE HERE
    ********************************************** -->
    
    @include('user.sidebarStu');
 
    <div id="wrapper">
        <!-- Sidebar -->
        <div id="sidebar-wrapper">
       
        <a class="navbar-brand with-text"><img src="{{asset('assets/images/cmyqual-logo.png')}}" class="dashboard-logo"></a>
            <ul class="sidebar-nav">
                <li class="active"><a href="#profile">Profile <span><i class="fa fa-user"></i></span></a></li>
                <!-- <li><a href="#my-courses">My Courses <span><i class="fa fa-briefcase"></i></span></a></li> -->
                <li class="active"><a href="#password">Password <span><i class="fa fa-key" aria-hidden="true"></i></span></a></li>
                <li class="active"><a href="#two-factor">Two factor authentication <span><i class="fa fa-info-circle" aria-hidden="true"></i></span></a></li>
               </ul>
        </div>
        <!-- /#sidebar-wrapper -->

        <div id="page-content-wrapper">
            <a href="#menu-toggle" class="menuopener" id="menu-toggle"><i class="fa fa-bars"></i></a>
            <div class="demo-parallax parallax section looking-photo nopadbot profile-bg" data-stellar-background-ratio="0.5" style="background-position: 0px 0px;">
                <div class="page-title section nobg nobg1">
                    <div class="container-fluid">
                        <div class="clearfix">
                            <div class="title-area pull-left">
                                <!-- <h2>My account</h2>   -->
                                <!---<small>Hello there, this is my profile.</small>--->
                            </div>
                            <!-- /.pull-right -->
                            <div class="pull-right hidden-xs">
                                <div class="bread">
                                    <ol class="breadcrumb">
                                       
                                        <li><a style="color:rgb(255 255 255 / 77%);">Setting</a></li>
                                      
                                        <li><a href="my-profile.php"><i class="fa fa-user-circle-o" aria-hidden="true"></i></a></li>
                                        <li><a href=""><i class="fa fa-bell-o" aria-hidden="true"></i></a></li>
                                        
                                    </ol>
                                </div>
                                <!-- end bread -->
                            </div>
                            <!-- /.pull-right -->
                        </div>


                        <!-- end clearfix -->
                    </div>
                </div>
                <!-- end page-title -->
             
            </div>
      
<div class="container-fluid">
<form class="form1" method="post" enctype="multipart/form-data" action="{{url('add-student')}}">
<div class="col-lg-12">
<div class="user-profile" id="profile">
<h5>Create Your Profile</h5>

<ul>
<li>
<label for="name" class=""><b>Name</b></label>
<input type="text" placeholder="Enter your name" class="control" name="name">
</li>
<li>
<label for="email" class=""><b>Email</b></label>
<input type="email" id="studentEmailId" class="control" placeholder="Enter your mail" name="email" required>
</li>
   {{ csrf_field() }}
<li>
<label for="photo" class=""><b>Photo</b></label>
<span class="change-user"><i class="fa fa-user" onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])"></i></span>
<div class="fileUpload">
<input type="file" class="upload control" name="profile" accept="image/*" onchange="document.getElementById('blah').src = window.URL.createObjectURL(this.files[0])"/>
 <span>Change</span>
</div>
<img id="blah" style="width: 62px;height:auto;border-radius: 50%;margin-left: 36px;"/>
</li>

<li>
<label for="dob" class=""><b>Date of Birth</b></label>
<input type="date" name="dob" class="control" max="<?php echo date('Y-m-d');?>">
</li>

<li><a href="javascript:void(0)"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
          <label for="country" class="country-dropdown"><b>Country</b></label>
          <select name="country" id="select" class="control" required> 
          <option value="">-- Select Country --</option>
 @foreach($country as $countryData)
   <option value="{{$countryData->id}}">{{$countryData->country_name}}</option>
@endforeach
</select>
</li>

<input type="text" name="form_id" hidden value="1"/>
<li><a href="javascript:void(0)"><i class="fa fa-link" aria-hidden="true"></i></a>
<label for="blog" class=""><b>Your Blog</b></label>
<input type="url" placeholder="nancysmith.com" name="blog_url" class="control mobile-url">

</li>
<li><a href="javascript:void(0)"><i class="fa fa-link" aria-hidden="true"></i></a>
<label for="portfolio" class="portfolio"><b>Portfolio</b></label>
<input type="url" class="control mobile-url" placeholder="nancysmith.com/portfolio" name="portfolio_url">

</li>
<!-- <li class="user-profile-btn">

<a href="#" class="btn cancel-btn" type="button" style="cursor:pointer;">Cancel</a>
<a href="#" class="btn save-changes" type="button" style="cursor:pointer;">Save changes</a>

</li> -->
<!-- <li class="user-profile-btn">
          <input type="reset" value="Reset">
          <input class="save-changes" type="submit" value="Submit">
</li> -->
</ul>


</div>
</div>

<div class="col-lg-12">
<div class="create-password user-profile" id="password">
<h5>Create Your Password</h5>
<!-- <form method="post" action="{{url('add-student')}}" class="form2"> -->
<ul>
<li><a href="javascript:void(0)"><i class="fa fa-eye" id="viewpassword" aria-hidden="true"></i></a>
<label for="psw" class="create-psw"><b>Password</b></label>
<input type="password" class="control" placeholder="" id="pwd" name="psw" required>

</li>
<li class="psw-option">
    <p><i class="fa fa-check" aria-hidden="true"></i>8 or more characters</p>
    <p><i class="fa fa-check" aria-hidden="true"></i> 1 Capital Letter & symbol</p>
    <p><i class="fa fa-check" aria-hidden="true"></i> 1 Number</p>
</li>
<li><a href="javascript:void(0)"><i class="fa fa-eye" id="viewConpassword" aria-hidden="true"></i></a>
<label for="psw" class=""><b>Confirm Password</b></label>
<input type="password" class="control" placeholder="" id="confirmPass" name="confirm_pwd" required>

</li>
<h5>Notification Setting</h5>
<p>
</p>
<div class="form-group">
                    <input type="checkbox" id="agree" class="notification-setting
 control-chk">
                    <label for="agree">
cMyQual sends notifications related to security, privacy and opportunities.  You can choose to unsubscribe to any email notifications once signed in.
</label>
</div>
<input type="text" name="form_id" hidden value="2"/>
<li class="user-profile-btn">
     <!--       <a href="#" class="btn cancel-btn" type="button" style="cursor:pointer;">Cancel</a>
           <a href="#" class="btn save-changes" type="button" style="cursor:pointer;">Save changes</a> -->
         <!--  <input type="reset" value="Reset">
          <input class="save-changes" id="btnForm2" type="submit" value="Submit"> -->
</li>
</ul>
<!-- </form> -->
</div>
</div>


<div class="col-lg-12">
<div class="create-password user-profile" id="two-factor">
<h5>Two factor authentication </h5>
<!-- <form method="post" action="{{url('add-student')}}" class="form3"> -->
<ul>
<div class="round">
    <br> 
    <div class="form-group">
      <input type="checkbox" id="html" name="email_confirm_status" class="email-authentication control-chk">
      <label for="html">VIA Email</label>
    </div>
    <!--<div class="form-group">-->
    <!--  <input type="checkbox" id="css" name="mobile_no_confirm_status" class="control-chk">-->
    <!--  <label for="css">VIA SMS</label>-->
    <!--</div>-->
   <input type="text" name="form_id" hidden value="3"/>
</div>
<div class="mobi-num">
<label for="number" class="mob-num"><b>Mobile No</b></label>
    <input type="text" placeholder="" id="mob-num" name="contact_no" required="" class="control">
</div>
<div class="hear">
                <p>Where did you hear about CMyQual?</p>
               <select id="select" class="control" name="why_like_cmyquals" class="why_cho_drop">
                    <option value="">Select - Optional</option>
                    <option value="google">Google</option>
                    <option value="career service team">Career Services Team</option>
                    <option value="lecture">University Lecture</option>
                    <option value="website">University Website</option>
                    <option value="facebook">Facebook</option>
                    <option value="linkedin">Linkedin</option>
                    <option value="other">Others</option>
                  </select>
</div>
<div class="round">
<div class="form-group">
            
       <input type="checkbox" id="javascript" name="term_condition_status" class="term-condition control-chk" required="">
      <label for="javascript">I agree to the terms of service and privacy policy</label>
</div>
</div>
<li class="user-profile-btn">
    <!--        <a href="#" class="btn cancel-btn" type="button" style="cursor:pointer;">Cancel</a>
           <a href="#" class="btn save-changes" type="button" style="cursor:pointer;">Save changes</a> -->
       <input type="reset" value="Reset" id="btnreset">
       <input class="save-changes" name="btnsubmit" type="submit" value="Submit">
</li>
</ul>
<!-- </form> -->

</div>
</div>

</form>
</div>      
</div>
    <!-- end wrapper -->

    <!-- ******************************************
    /END SITE
    ********************************************** -->

    <!-- ******************************************
    DEFAULT JAVASCRIPT FILES
    ********************************************** -->
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js'></script>
    <script src="{{asset('assets/js/all.js')}}"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/easy-pie-chart/2.1.6/jquery.easypiechart.min.js'></script>
    <script src="{{asset('assets/js/custom.js')}}"></script>
    <script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
    <script>
    
    
$('#btnreset').on('click',function(){
 alert();   
$('#blah').attr('src','');
});

$('#viewpassword').on('click',function(){
 $('#pwd').attr('type','text');  
});

$('#viewConpassword').on('click',function(){
 $('#confirmPass').attr('type','text'); 
});

        $(window).scroll(function() {
    var windscroll = $(window).scrollTop();
    if (windscroll >= 100) {
      $('#sidebar-wrapper').each(function(i) {
        // The number at the end of the next line is how pany pixels you from the top you want it to activate.
        if ($(this).position().top <= windscroll - 0) {
          $('ul.sidebar-nav li.active').removeClass('active');
          $('ul.sidebar-nav li').eq(i).addClass('active');
        }
      });

    } else {

      $('ul.sidebar-nav li.active').removeClass('active');
      $('ul.sidebar-nav li:first').addClass('active');
    }

    }).scroll();
    </script>
    <script type="text/javascript">

    $('.save-changes').on('click',function(){
    
    if(! $('.notification-setting').is(':checked')){
    
    alert('Please accept the notification setting');
    return false;
    
    }else if(! $('.email-authentication').is(':checked')){
    
    alert('Please accept the email authentication');
    return false;
    
    }else if(! $('.term-condition').is(':checked')){
    
    alert('Please accept the terms of service and privacy policy');
    return false;
    
    }else{
    return true;
    }
    
    });

$.validator.addMethod("regx", function(value, element, regexpr){          
    return regexpr.test(value);
}, "Please enter a valid pasword.");
$('.form1').validate({

 rules:{
  name:{
   required:true,
   minlength:3, 
   maxlength:30,   
  },
  email:{
   required:true,
   email:true,
   remote:{
   url: "<?php echo url('check-student-email');?>",
   type: "post",
   data:{emailId:$('#studentEmailId').val(),"_token":'{{csrf_token()}}'},
            }  
  },
  profile:{

  },
  dob:{
   required:true,
  },
  country:{
  required:true,
  },
  blog_url:{

  url:true,
  }, 
  portfolio_url:{

  url:true,
  }, 
 psw:{
required:true,
regx: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
},
confirm_pwd:{
 equalTo: "#pwd"
},
    contact_no:{
    required:true,
    minlength:10,
    maxlength:15,
    remote:{
    url: "<?php echo url('check-student-contactno');?>",
    type: "post",
    data:{mobile:$('#mob-num').val(),"_token":'{{csrf_token()}}'},
            }  
    }
 },
 messages:{
   name:{
   required:'Please enter name', 
   },
   email:{
   required:'Please enter email id',
   remote:'This email ID already exists. Please enter another one.',
   },
   profile:{
 
   },
   dob:{
   required:'Please enter DOB',
   }, 
   country:{
   required:'Please select country',
   },
   blog_url:{

   },
   portfolio_url:{
 
   },
   psw:{
   required:'Please enter password',
   },
   confirm_pwd:{
   required:'Please enter confirm password',       
   equalTo:'Password & confirm password not match',
   },
   contact_no:{
   required:'Please enter contact no',
   remote:'This contact no already exists. Please enter another one.',
   }   
   }
});
 
    $(function() {
    $('.chart').easyPieChart({
      size: 115,
      barColor: "#fff",
      scaleLength: 0,
      lineWidth: 8,
      trackColor: "#3333",
      lineCap: "circle",
      animate: 2000,
    });
  });
    </script>
    
<script>
window.chartColors = {
  red: 'transparent',
  orange: 'tranparent',
//   yellow: 'rgb(255, 205, 86)',
  green: 'rgb(75, 192, 192)',
  blue: '#fff',
//   purple: 'rgb(153, 102, 255)',
//   grey: 'rgb(231,233,237)'
};

var randomScalingFactor = function() {
  return (Math.random() > 0.5 ? 1.0 : 1.0) * Math.round(Math.random() * 25);
};

var line1 = [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), ];

var line2 = [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), ];

var MONTHS = ["1/3", "8/3", "15/3", "22/5"]; //"May", "June", "July", "August", "September", "October", "November", "December"
var config = {
  type: 'line',
  data: {
    labels: MONTHS,
    datasets: [{
      label: "",
      backgroundColor: window.chartColors.red,
      borderColor: window.chartColors.red,
      data: line1,
      fill: false,
    }, {
      label: "",
      fill: false,
      backgroundColor: window.chartColors.blue,
      borderColor: window.chartColors.blue,
      data: line2,
    }]
  },
  options: {
    responsive: true,
    title:{
      display:true,
      text:''
    },
    tooltips: {
      mode: 'index',
      intersect: false,
    },
   hover: {
      mode: 'nearest',
      intersect: true
    },
    scales: {
      xAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: ''
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
        },
      }]
    }
  }
};

var ctx = document.getElementById("canvas").getContext("2d");
var myLine = new Chart(ctx, config);

var data1 = [
  randomScalingFactor(),
  randomScalingFactor(),
];

// var data2 = [
//   randomScalingFactor(),
//   randomScalingFactor(),
// ];

var ctx = document.getElementById("chart-area").getContext("2d");
var myPie = new Chart(ctx, {
  type: 'pie',
  data: {
        labels: ["FTE", "FTC"],
    datasets: [{
      label: 'Dataset 1',
      data: data1,
      backgroundColor: [
        "",
        ""
      ],
      hoverBackgroundColor: [
        "",
        ""
      ],
      borderWidth: 5,
    }, {
      label: 'Dataset 2',
      data: data2,
      backgroundColor: [
        "",
        ""
      ],
      hoverBackgroundColor: [
        "",
        ""
      ],
      borderWidth: 5,
    }],
  },
  options: {
    title: {
      display: true,
      text: 'Employee Overview',
      fontStyle: 'bold',
      fontSize: 20
    }
  }
});


  var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
    }
  };

/*
$('a[href="#pie"]').on('shown.bs.tab', function(){
  myPie.update();
});
*/
</script>
</body>


</html>