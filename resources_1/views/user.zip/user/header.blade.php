<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<header class="header normal-header" data-spy="affix" data-offset-top="197">
            <div class="container">
                <nav class="navbar navbar-default yamm">
                    <div class="container-full">
                        <div class="navbar-header">
                          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" href="{{url('')}}"><img src="{{asset('assets/images/cmyqual-logo-header.png')}}"></a>
                        </div>
                        <!-- end navbar header -->

                        <div id="navbar" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="{{url('learner')}}">Learners</a></li> 
                                <li><a href="{{url('employers')}}">Employers</a></li>
                                <li><a href="{{url('association')}}">Associations</a></li>
                                <li><a href="{{url('learning-institutions')}}">Learning institutions</a></li>
                                <li><a href="{{url('online-learning-partner')}}">Online learning Partners</a></li>
                                 <li class="dropdown normal-menu has-submenu mobile-get-started-desktop">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Get Started <span class="fa fa-angle-down"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="{{route('user-signup')}}">Life Long Learner</a></li>
                                        <li><a href="{{route('employer-signin')}}">Employer Registration</a></li>
                                        <li><a href="{{route('l-p-signin')}}">Learning Partner Signup</a></li>
                                      
                                    </ul>
                                 </li>
                      
                            <ul class="nav navbar-nav navbar-right" style="position: absolute;right: 0;">

                                <!--<li class="cartmenu"><a href="course-checkout.html"><i class="fa fa-shopping-bag"></i> <sup>2</sup></a></li>-->
                                <li class="dropdown cartmenu searchmenu hasmenu">
                                    <!-- <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-search"></i></a> -->
                                    <ul class="dropdown-menu start-right">
                                        <li>
                                            <div id="custom-search-input">
                                                <div class="input-group">
                                                    <input type="text" class="form-control input-lg" placeholder="Search here..." />
                                                    <span class="input-group-btn">
                                                        <button class="btn btn-primary btn-lg" type="button">
                                                            <i class="fa fa-search"></i>
                                                        </button>
                                                    </span>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li> 
                                <div class="dropdown2">
                                <li class="dropbtn btn btn-default get-start-btn">
                                    <a title="Get Started" href="">Get Started</a>

                                </li>
                                <div class="dropdown-content">
                                    <a href="{{url('user-login')}}">Life-Long<br> Learner</a>
                                    <a href="{{url('employer/login')}}">Employer Registration</a>
                                    <a href="{{url('partner/login')}}">Learning Partner Signup</a>
                                  
                                </div>
                                </div>
                                <!--<li class="btn btn-default"><a title="Join for free" href="login.php">Login</a></li>-->
                            </ul>
                            <!-- end dropdown -->
                        </div>
                        <!--/.nav-collapse -->
                    </div>
                    <!--/.container-fluid -->
                </nav>
                <!-- end nav -->
            </div>
            <!-- end container -->
        </header>
        <!-- end header -->