
        <div id="sidebar-wrapper">
            <a class="navbar-brand with-text"><img src="images/cmyqual-logo.png" class="dashboard-logo"></a>
            <ul class="sidebar-nav">
                <li class="active"><a href="{{url('user/profile')}}">Home <span><i class="fa fa-home" aria-hidden="true"></i></span></a></li>
                <!-- <li><a href="#my-courses">My Courses <span><i class="fa fa-briefcase"></i></span></a></li> -->
                <li><a href="{{url('user/goal')}}">Goals <span><i class="fa fa-bullseye" aria-hidden="true"></i></span></a></li>
                <li><a href="{{url('user/achievement')}}">Achievements <span><i class="fa fa-trophy"></i></span></a></li>
                <li><a href="{{url('user/cpd-log')}}">CPD Log <span><i class="fa fa-info-circle" aria-hidden="true"></i></span></a></li>
                <li><a href="{{url('user/shared')}}">Shared Lists<span><i class="fa fa-share-alt"></i></span></a></li>
                
              
            </ul>
        </div>