<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- SITE META -->
    <title>CMYQUAL</title>
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keywords" content="">

    <!-- FAVICONS -->
   
    <!-- BOOTSTRAP STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/bootstrap.min.css')}}">
    <!-- TEMPLATE STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/style.css')}}">
    <!-- RESPONSIVE STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/responsive.css')}}">
    <!-- COLORS STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/colors.css')}}">
    <!-- CUSTOM STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/custom.css')}}">
    <!---- Select 2 ----->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
    <!---- end Select 2 ----->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<style>
.about-widget .team-member-name {
    padding-top: 30px;
}
.team-member-name img{width:25%; height: 45%;   border-radius: 50%;
    border: 1px solid #1d9b75;}
.change-career .box .chart
{
    margin-left:40px;
}
.team-member-name
{
    background: #fff;
    border-radius: 8px;
    margin: 20px 0;
   padding-left: 20px;
    padding-right: 20px;
    border: 0.847222px solid rgba(0, 0, 0, 0.12);
        height: 243px;
}
    html{scroll-behavior: smooth;}
    .select2-container--default .select2-selection--multiple
    {
        border:none!important;
        border-radius:0px!important;
    }
    .share-achievement-list-program .col-lg-4 , .share-achievement-list-program .col-lg-8
    {
        margin-top:20px;
    }
.select2{
width:370px !important;
padding-right:0px !important; 
}
.select2-search__field{
width:360px !important;
}
.tesla-box select
{
    height:30px;
}
.team-member-img img
{
        margin-top: 20px;
   
    padding: 5px;

}
.team-member-img {
    background-color:  #1d9b75;
}
.about-widget h5
{
    font-weight: 700;
    font-family: 'Roboto' , sans-serif!important;
    font-size: 13px;
}
/*.modal-content.shared-scroll*/
/*{*/
/*  overflow-y: scroll;*/
/*    overflow-x: hidden;*/
/*    height: 550px;*/
/*}*/
/* width */
.team-member-name p::-webkit-scrollbar {
  width: 5px;
}

/* Track */
.team-member-name p::-webkit-scrollbar-track {
  background: #f1f1f1; 
}
 
/* Handle */
.team-member-name p::-webkit-scrollbar-thumb {
  background: #888; 
}

/* Handle on hover */
.team-member-name p::-webkit-scrollbar-thumb:hover {
  background: #555; 
}
.team-member-name p
{
        overflow-y: scroll;
        height: 100px!important;
}
.about-widget p
{
     overflow-y: scroll;
     height: 70px;
}
.about-widget p.spread
{
     overflow-y: unset;
     height: auto;
}
.about-widget p::-webkit-scrollbar {
  width: 5px;
}

/* Track */
.about-widget p::-webkit-scrollbar-track {
  background: #f1f1f1; 
}
 
/* Handle */
.about-widget p::-webkit-scrollbar-thumb {
  background: #888; 
}

/* Handle on hover */
.about-widget p::-webkit-scrollbar-thumb:hover {
  background: #555; 
}
#expDate{
    margin: 5px 0 0px 50px;
    width: 83%;
    padding: 5px 10px 5px 10px;
    background-color: #fff;
    border: 1px solid rgb(62 163 164 / 55%);
     },
.pickupdate{
     margin: 5px 0 0px 50px;
    width: 83%;
    padding: 5px 10px 5px 10px;
    background-color: #fff;
    border: 1px solid rgb(62 163 164 / 55%);   
}     
 #summary
{
    margin: 5px 0 0px 84px;
    width: 83%;
    padding: 9px 10px 9px 10px;
    border: none;
    background: #fff;
    font-size: 12px;
    max-height: 70px;
    border: 1px solid rgb(62 163 164 / 55%);
}     
.error{
 border-color:#ef3f17cc !important;    
}     

     
</style>
<body class="dashboard-background leftmenu memberprofile">

    <!-- PRELOADER -->
    <!-- <div class="cssload-container">
        <div class="cssload-loader"></div>
    </div> -->
    <!-- end PRELOADER -->

    <!-- ******************************************
    START SITE HERE
    ********************************************** -->
     @include('user.sidebarStu') 
    <div id="wrapper">
     @include('user.sidebar')

        <div id="page-content-wrapper">
            <a href="#menu-toggle" class="menuopener" id="menu-toggle"><i class="fa fa-bars"></i></a>
            <div class="demo-parallax parallax section looking-photo nopadbot profile-bg profile-bg2" data-stellar-background-ratio="0.5">
                <div class="page-title section nobg">
                    <div class="container-fluid">
                        <div class="clearfix">
                            <div class="title-area pull-left">
                                <!-- <h2>My account</h2>   -->
                                <!---<small>Hello there, this is my profile.</small>--->
                            </div>
                            <!-- /.pull-right -->
                            <div class="pull-right hidden-xs">
                                <div class="bread">
                                    <ol class="breadcrumb my-profile">
                                        <li><a href="{{url()}}"><i class="fa fa-home" aria-hidden="true"></i></a></li>
                                        <li><a href="{{url('user/profile')}}">My Profile</a></li>
                                        <!-- <li><a href="">Unfiled Organization</a></li> -->
                                    </ol>
                                </div>
                                <!-- end bread -->
                            </div>
                            <!-- /.pull-right -->
                        </div>
                        <!-- end clearfix -->
                    </div>
                </div>
                <!-- end page-title -->
            </div>

            <div class="section" id="my-profile">
                <div class="container-fluid">
                    <div class="row">
                    

                        <div class="col-md-12 col-sm-12">
                            <div class="about-widget clearfix">
                                <div class="widget-title">
                                    <!-- <h1 class="heading1">My Profile</h1> -->
                                   
                                </div><!-- end title -->
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <div class="team-member-img text-center">
                                          @if($userInfo->photos)
                                         <img src="{{asset('public/uploads/user/'.$userInfo->photos)}}" alt="team member img" class="img-responsive">
                                           @else
                                          <img src="{{asset('assets/images/default_user.png')}}" alt="team member img" class="img-responsive"> 
                                          @endif 
                                        </div>
                                          <h5 class="text-center">Welcome, <br>{{$userInfo->name}}!</h5>
                                  
                                            
                                    </div>

                                    <div class="col-md-4 col-sm-6">
                                        <div class="team-member-name">
                                       <img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSXanJlp8fSM6vn8JGF8Oym7VnL3GkBA8Xu2QN3TYD3dDzhE8Nc">
                                        <!--<h5>{{$userInfo->name}}!</h5>-->
                                        <p><i>{{$quotes['quote']}}<br>_____{{$quotes['by']}}</i></p>
                                            
                                        </div>
                                       
                                        <hr class="invis">

                   

                                    </div><!-- end col -->
<div class="col-lg-3 col-md-3 col-sm-12 text-center">
   <div class="change-career">
   <span><i class="fa fa-bullseye" aria-hidden="true"></i> Current Goal</span>
   <h4>Change Career</h4>
   <div class="box text-center">
    <div class="chart" data-percent="20" data-scale-color="#CED6DC">20% - Complete<canvas height="160" width="160"></canvas></div>
   </div>
   <section class="sec1 text-left">
   <span><i class="fa fa-check" aria-hidden="true"></i> Completed</span>
   </section>
   <section class="sec2 text-right">
   <span>See more <i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
   </section>
   </div>
</div>
<div class="col-lg-3 col-md-3 col-sm-12">
<div class="change-career iac">
<h4 class="text-center"><i class="fa fa-envelope-o" aria-hidden="true"></i> Invite a Colleague</h4>

<p class="text-center spread">
Spread the word by inviting a friend or colleague and you both get a free 1v1 coaching session with our career experts.
</p>
<div class="space text-center">
<a href="#" class="btn btn-primary" type="button" data-toggle="modal" data-target="#inviteModal" style="cursor:pointer;background-color:  #1D9B75!important;border-radius:4px!important;text-transform:uppercase;padding-top: 10px;
    padding-bottom: 10px;">Invite</a>
</div>
</div>                              
 </div>

<div class="col-lg-12 col-md-12 col-sm-12 text-center new-figma-achievement-box">
<div class="col-lg-6 col-md-6 col-sm-6 text-center">
  <div class="achievement-box">
    <h4 class=""><i class="fa fa-caret-down" aria-hidden="true"></i> Achievements <span class="tree-span text-center">1 Expiring Soon</span></h4>
    
<div class="tree-main">
    
    <div class="tree1">
    <span>@if($levelOne[0]->achivementType=='edu')
    <i class="fa fa-graduation-cap" aria-hidden="true"></i>
    @elseif($levelOne[0]->achivementType=='other')
    <i class="fa fa-trophy" aria-hidden="true"></i> 
    @else
    @endif
    {{$levelOne[0]->achivementName}}</span>
    </div>
  
    <div class="tree2">
    <span>@if($levelTwo[0]->achivementType=='edu')
    <i class="fa fa-graduation-cap" aria-hidden="true"></i>
    @elseif($levelTwo[0]->achivementType=='other')
    <i class="fa fa-trophy" aria-hidden="true"></i>
    @else
    @endif
    {{$levelTwo[0]->achivementName}}</span>
    </div>
  
    <div class="tree3">
    <span>@if($levelThree[0]->achivementType=='edu')
    <i class="fa fa-graduation-cap" aria-hidden="true"></i>
    @elseif($levelThree[0]->achivementType=='other')
     <i class="fa fa-trophy" aria-hidden="true"></i>
    @else
    @endif
    {{$levelThree[0]->achivementName}}</span>
    </div>
  
    <div class="tree4">
    <span>@if($levelFour[0]->achivementType=='edu')
    <i class="fa fa-graduation-cap" aria-hidden="true"></i>
     @elseif($levelFour[0]->achivementType=='other')
      <i class="fa fa-trophy" aria-hidden="true"></i>
    @else
    @endif
    {{$levelFour[0]->achivementName}}</span>
    </div>
  
    <div class="tree5">
    <span>@if($levelFive[0]->achivementType=='edu')
   <i class="fa fa-graduation-cap" aria-hidden="true"></i>
    @elseif($levelFive[0]->achivementType=='other')
   <i class="fa fa-trophy" aria-hidden="true"></i>
    @else
    
    @endif
    {{$levelFive[0]->achivementName}}</span>
    </div>
  
    <div class="tree6">
    <span>@if($levelSix[0]->achivementType=='edu')
    <i class="fa fa-graduation-cap" aria-hidden="true"></i>
    @elseif($levelSix[0]->achivementType=='other')
    <i class="fa fa-trophy" aria-hidden="true"></i>
    @else
    @endif{{$levelSix[0]->achivementName}}</span>
    </div>

    <div class="tree-root">
    </div>

</div>

    
  </div>
</div>
<div class="col-lg-6 col-md-6 col-sm-12 text-left">
<div class="achievment-tree-list add-new">

<div class="col-lg-6 col-md-6 col-sm-6">
<div class="add-new-box">
    <span type="button" data-toggle="modal" data-target="#myModal" style="cursor:pointer;">Add New +</span>
</div>

</div>

@foreach($achivementInfo as $achivementInfoData)
<div class="col-lg-9 col-md-9 col-sm-12">
        <h6><i class="fa fa-trophy" aria-hidden="true"></i>{{$achivementInfoData->achivementName}}</h6><span>Coursera . Achieved 1 week ago</span>
</div>
<div class="col-lg-3 col-md-3 col-sm-12 text-right">
<i class="fa fa-file-pdf-o" aria-hidden="true"></i> PDF <a href="{{asset('public/achivementPDF/'.$achivementInfoData->pdfFile)}}" target="_blank"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></a>
</div>
<div class="add-new-border"></div>
@endforeach
<div class="col-lg-12">
<a href="{{url('user/achievement')}}"><span class="see-cpd">See All Achievement</span></a>
</div>
</div>
</div>
</div>

<div class="col-lg-12 new-figma-recent">
    <div class="col-lg-6 col-md-6 col-sm-12">
    <h4><i class="fa fa-caret-down" aria-hidden="true"></i>  CPD Logs</h4>
    <div class="hour-logged hour-logged2">
      <span><h4>32 Hours Logged in past 4 weeks</h4></span>
      
      <span class="hour-logged"><span>+34%</span> from previous period </span>
      <div class="line-chart">
        <canvas id="canvas"></canvas>
      </div>
  </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12">
<div class="achievment-tree-list cpd">

<div class="col-lg-6 col-md-6 col-sm-6">
<div class="add-new-box" type="button" data-toggle="modal" data-target="#goalModal" style="cursor:pointer;">
    <span>Add New +</span>
</div>
</div>

@foreach($logInfo as $logInfoData)
<div class="col-lg-9 col-md-9 col-sm-12">
<h6>{{$logInfoData->title}}</h6><span style="padding-left:0px;">23 March 2021 . 8 Hours</span>
</div>
<div class="col-lg-3 col-md-3 col-sm-12 text-right">
 <i class="fa fa-file-pdf-o" aria-hidden="true"></i> PDF <a href="{{asset('public/cpdLogPDF/'.$logInfoData->pdfFile)}}" target="_blank"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></a>
</div>
<div class="add-new-border"></div>
@endforeach

<div class="col-lg-12">
    <a href="{{url('user/cpd-log')}}"><span class="see-cpd">See All CPD Logs</span></a>
</div>
</div>
</div>
</div>
<div class="col-lg-12 new-figma-share-view">
<div class="col-lg-6 col-md-6 col-sm-12 text-center">
<h4 class="text-left"><i class="fa fa-caret-down" aria-hidden="true"></i>  Sharing lists</h4>
<div class="hour-logged hour-logged2">
      <span class="text-left"><h4>33 views in past 4 weeks</h4></span>
      <div class="line-chart"><iframe class="chartjs-hidden-iframe" tabindex="-1" style="display: block; overflow: hidden; border: 0px; margin: 0px; inset: 0px; height: 100%; width: 100%; position: absolute; pointer-events: none; z-index: -1;"></iframe>
        <canvas id="share-canvas" width="435" height="212" style="display: block; width: 435px; height: 212px;"></canvas>
      </div>
  </div>
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
<div class="achievment-tree-list">

<div class="col-lg-6 col-md-6 col-sm-6">
<div class="add-new-box" type="button" data-toggle="modal" data-target="#shareModal" style="cursor:pointer;">
    <span>Add New +</span>
</div>
</div>

@foreach($sharedListInfo as $sharedListInfoData)
<div class="col-lg-8 col-md-8 col-sm-12">
        <h6><i class="fa fa-share-alt" aria-hidden="true"></i> Tesla Motors</h6><span>Created 5 minutes ago</span>
</div>

<div class="col-lg-4 col-md-4 col-sm-12 text-right">
<ul>
    <li>
    <i class="fa fa-eye" aria-hidden="true"></i> 
    </li>
    <li>
    <span>24 views</span>
    </li>
    <li>
    <i class="fa fa-ellipsis-h" aria-hidden="true"></i>
    </li>
</ul>
</div>
<div class="add-new-border"></div>
@endforeach

<div class="col-lg-12">
    <span class="see-cpd">See All Shared Lists</span>
</div>
</div>
</div>
</div>
 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
    <h4 class="heading1">Share My Learning Record</h4>
    <ul>
        <li>Share list only</li>
        <li>Share list and certificates</li>
        <li>Share Validated and verified certificates</li>
        <li>Cancel</li>
    </ul>
 </div>
 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
    <h4 class="heading1">Unfiled Items</h4>
    <ul>
        <li><a href="">Fwd:Course1</a></li>
        <li><a href="">Fwd:Course2</a></li>
        <li><a href="">Fwd:Course3</a></li>
        <li><a href="">Fwd:Course4</a></li>
    </ul>
 </div>
                                </div><!-- end row -->      
                            </div><!-- end widget -->
                        </div><!-- end col -->

               
                    </div><!-- end row -->
                </div><!-- end container -->
                <section class="profile-member">
        <div class="container-fluid">
            <div class="row">
            <div class="col-lg-6">
            <h4 class="heading1">Membership</h4>
            </div>
            <div class="col-lg-6">
            <h4 class="heading1">Certificate</h4>
            <ul class="certificate-list">
            
                <li>
                     <img src="images/certificate1.jpg">
                     
                </li>
                <li>
                     <img src="images/certificate2.jpg">
                    
                </li>
                <li>
                     <img src="images/certificate3.jpg">
                     
                </li>
            </ul>
            </div>
            </div>
        </div>
        </div>
        </section>
        <div class="section lb" id="my-courses">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="clearfix">
                                <div class="widget-title">
                                <h4 class="heading1">Upcoming Courses</h4>
                                   
                                </div>
                                <div class="row">
                                
                                    <div class="col-lg-5 col-md-5">
                                        <div class="video-wrapper clearfix">
                                            <div class="post-media">
                                                <div class="entry">
                                                    <img src="upload/blog_01.jpg" alt="" class="img-responsive">
                                                    <div class="magnifier">
                                                        <div class="magni-desc">
                                                            <a class="secondicon" href="course-single.html"> <span class="oi" data-glyph="link-intact" title="Read More" aria-hidden="false"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-7 col-md-7">
                                        <div class="video-wrapper">
                                            <div class="widget-title clearfix">
                                            
                                                <h3><a>Learn English in 20 Days</a></h3>
                                                <div class="rating">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                                <small><a href="#">View Course</a>  -  Expires : 22 June 2016</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                               

                                <div class="row">
                                    <div class="col-lg-5 col-md-5">
                                        <div class="video-wrapper clearfix">
                                            <div class="post-media">
                                                <div class="entry">
                                                    <img src="upload/blog_02.jpg" alt="" class="img-responsive">
                                                    <div class="magnifier">
                                                        <div class="magni-desc">
                                                            <a class="secondicon" href="course-single.html"> <span class="oi" data-glyph="link-intact" title="Read More" aria-hidden="false"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-7 col-md-7">
                                        <div class="video-wrapper">
                                            <div class="widget-title clearfix">
                                                <h3><a>Learning Web Design</a></h3>
                                                <div class="rating">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                                <small><a href="#">View Course</a>  -  Expires : 22 June 2016</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                               

                                <div class="row mobile-hidden">
                                    <div class="col-lg-5 col-md-5">
                                        <div class="video-wrapper clearfix">
                                            <div class="post-media">
                                                <div class="entry">
                                                     <!-- <img src="upload/blog_03.jpg" alt="" class="img-responsive"> -->
                                                    <div class="magnifier">
                                                        <div class="magni-desc">
                                                            <a class="secondicon" href="course-single.html"> <span class="oi" data-glyph="link-intact" title="Read More" aria-hidden="false"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                              

                               <div class="row mobile-hidden">
                                    <div class="col-lg-5 col-md-5">
                                        <div class="video-wrapper clearfix">
                                            <div class="post-media">
                                                <div class="entry">
                                                    <!-- <img src="upload/blog_04.jpg" alt="" class="img-responsive"> -->
                                                    <div class="magnifier">
                                                        <div class="magni-desc">
                                                            <a class="secondicon" href="course-single.html"> <span class="oi" data-glyph="link-intact" title="Read More" aria-hidden="false"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                   
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="register-widget clearfix">
                                <div class="widget-title expire-course">
                                    <h4 class="heading1" style="visibility:hidden;">Expired Courses</h4>
                                   
                                </div>
                 
                                <div class="row">
                                    <div class="col-lg-5 col-md-5">
                                        <div class="video-wrapper clearfix">
                                            <div class="post-media">
                                                <div class="entry">
                                                    <img src="upload/blog_05.jpg" alt="" class="img-responsive">
                                                    <div class="magnifier">
                                                        <div class="magni-desc">
                                                            <a class="secondicon" href="course-single.html"> <span class="oi" data-glyph="link-intact" title="Read More" aria-hidden="false"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-7 col-md-7">
                                        <div class="video-wrapper">
                                            <div class="widget-title clearfix">
                                                <h3><a>Working with a Group</a></h3>
                                                <div class="rating">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                </div>
                                                <small><a href="#">View Course</a>  -  <a href="#">Expired : Re-join the course</a></small>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                           

                                <div class="row">
                                    <div class="col-lg-5 col-md-5">
                                        <div class="video-wrapper clearfix">
                                            <div class="post-media">
                                                <div class="entry">
                                                    <img src="upload/blog_06.jpg" alt="" class="img-responsive">
                                                    <div class="magnifier">
                                                        <div class="magni-desc">
                                                            <a class="secondicon" href="course-single.html"> <span class="oi" data-glyph="link-intact" title="Read More" aria-hidden="false"></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-7 col-md-7">
                                        <div class="video-wrapper">
                                            <div class="widget-title clearfix">
                                                <h3><a>5 Step to Build a Website</a></h3>
                                                <div class="rating">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star-o"></i>
                                                </div>
                                                <small><a href="#">View Course</a>  -  <a href="#">Expired : Re-join the course</a></small>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    

                                </div>
                            </div>
                            
                        </div>
                        
                    </div>
                </div>
            </div> 
            </div><!-- end section -->
        <!-- end copyrights -->

        <!-- end page-content-wrapper -->
       
    </div>
    <!-- end wrapper -->
     <!-- Modal -->
  <div class="modal fade" id="shareModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
         
          <h4 class="modal-title modal-title1"><i class="fa fa-share-alt"></i> <span style="font-size:13px;color: #333;">Shared List</span> Tesla Motors</h4>
        </div>

       <form method="post" action="{{url('add-shared-list')}}"> 
        <div class="modal-body">
         @csrf
        <div class="modal-list modal-list-form">
        
        <div class="tesla-box">
            <div class="col-lg-6 col-md-6 text-left">
             <span class="tesla-invite"><i class="fa fa-envelope-o" aria-hidden="true"></i> Invites</span>
            </div>

            <div class="col-lg-6 col-md-6 text-right">
            <span class="tesla-invite tesla-invite1">Preview <i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
            </div>

            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
            <label for="create-invite" class="create-invite"><b>Create Invite</b></label>
            </div>

            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
            <input type="email" name="email" placeholder="joes@gmail.com" required="">
           </div>

           <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
           <select name="expireDate" id="select" required="">
                    <option value="30">Expire in 30 Days</option>
                    <option value="20">Expire in 20 Days</option>
                    <option value="10">Expire in 10 Days</option>
                    <option value="5">Expire in 5 Days</option>
          </select>
           </div>

           <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
           <label for="sent-invite" class="sent-invite"><b>Sent Invites</b></label>
           </div>

           <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
           <input type="email" name="receiverInvitationMail[]" required="">
           </div>
           </div>
            <!-- <ul>
                <li>
                <label for="create-invite" class="create-invite"><b>Create Invite</b></label>
                <input type="email" name="email">
                </li>
            </ul> -->
        </div>
<div class="shared-search">
<div class="col-lg-4 col-md-4 col-sm-6">
<h5>Shared Achievements</h5>
</div>

<div class="col-lg-8 col-md-8 col-sm-6 text-right">

<select name="achivementList[]" multiple="multiple" class="js-example-basic-multiple-achivement">
  <option value="">Select Achivement</option>
  @foreach($achivementInfo as $achivementInfoDropVal)
  <option value="{{$achivementInfoDropVal-id}}">{{$achivementInfoDropVal->achivementName}}</option>
  @endforeach
</select>
<!-- 
<input type="text" id="getAchievement" name="getAchievement" placeholder="Find achievement to add">
 -->
</div>
</div>

<section class="share-achievement-list-program">

@foreach($achivementInfo as $achKey=>$achivementInfoData)
@if($achKey==0)
<div class="share-achievement-outer">
<div class="col-lg-6 col-md-6 col-sm-6">
        <h5><i class="fa fa-graduation-cap" aria-hidden="true"></i>{{$achivementInfoData->achivementName}}</h5><span>Achieved 1 week ago</span>
</div>

<div class="col-lg-6 col-md-6 col-sm-6 text-right">
        <i class="fa fa-file-pdf-o" aria-hidden="true"></i> PDF <a href="{{asset('public/achivementPDF/'.$achivementInfoData->pdfFile)}}" target="_blank"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></a>
</div>
</div> 
@else
<div class="col-lg-12 share-achievement-outer share-achievement-outer1" style="">
<div class="col-lg-6 col-md-6 col-sm-6">
        <h5><i class="fa fa-graduation-cap" aria-hidden="true"></i>{{$achivementInfoData->achivementName}}</h5><span>Achieved 1 week ago</span>
</div>

<div class="col-lg-6 col-md-6 col-sm-6 text-right">
        <i class="fa fa-file-pdf-o" aria-hidden="true"></i> PDF <a href="{{asset('piblic/achivementPDF/'.$achivementInfoData->pdfFile)}}" target="_blank"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></a>
</div>
</div>  
@endif
@endforeach
<div class="row">

<div class="col-lg-4 col-md-4 col-sm-6">
<h5>CPD Log</h5>
</div>

<div class="col-lg-8 col-md-8 col-sm-6 text-right">

<select name="cpdList[]" multiple="multiple" class="js-example-basic-multiple-sharedLog">
  <option value="">Select CPD Logs</option>
  @foreach($logInfo as $logInfoVal)
  <option value="{{$achivementInfoDropVal-id}}">{{$logInfoVal->title}}</option>
  @endforeach
</select>
<!-- 
<input type="text" id="getAchievement" name="getAchievement" placeholder="Find achievement to add">
 -->
</div>
</div>

<div class="shared-logs-assesement col-lg-12">
  <h5>Shared logs</h5>
@foreach($logInfo as $logInfoData)
<div class="shared-log-asses-border">
  <div class="col-lg-6 col-md-6 col-sm-6">
        <h5><i class="fa fa-graduation-cap" aria-hidden="true"></i>{{$logInfoData->title}}</h5><span>Achieved 1 week ago</span>
</div>

<div class="col-lg-6 col-md-6 col-sm-6 text-right">
      <i class="fa fa-file-pdf-o" aria-hidden="true"></i> PDF <a href="{{asset('public/cpdLogPDF/'.$logInfoData->pdfFile)}}" target="_blank"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></a> 
</div>
</div>
@endforeach
</div>
 
</section>
<div class="space text-left">
            <button class="btn btn-primary" type="submit" style="cursor:pointer;background-color: #1D9B75!important;">Add List</button>
</div>
        </div>
      </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal -->
  <div class="modal fade" id="goalModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
         
          <h4 class="modal-title modal-title1"><i class="fa fa-info-circle" aria-hidden="true"></i><span style="font-size:13px;color: #333;">CPD Log</span> Oakhaven Hospice</h4>
        </div>
        <div class="modal-body">
     
        <div class="modal-list modal-list-form">
          <form method="post" action="{{url('add-cpd-log')}}" id="cpd-log"> 
         @csrf
         <ul>

            <li>
            <label for="title" class="title"><b>Title</b></label>
            <input type="text" id="title" placeholder="Developement (max 35 min 3)" maxlength="35" minlength="3" name="title" style="margin-left:53px;" required>
            </li>
            <li>
            <label for="date" class="cpd-date"><b>Date</b></label>
            <input type="date" id="date" style="margin: 5px 0 0px 50px;width: 83%;padding: 5px 10px 5px 10px;background-color: #fff;border: 1px solid rgb(62 163 164 / 55%); " name="date" placeholder = "dd/mm/yyyy" required>
            </li>
    
            <li>
            <label for="provider" class="provider"><b>Provider</b></label>
            <input type="text" placeholder="Organization Name (max 35 min 3)" name="provider" required><i class="fa fa-pencil-square-o a-pencil pencil1" aria-hidden="true"></i>
           </li>
           <li>
            <label for="standard" class="provider"><b>Standard</b></label>
            <input type="text" placeholder="1 or 2 (max 3 min 1)" name="standard" maxlength="3" minlength="1" required><i class="fa fa-pencil-square-o a-pencil pencil1" aria-hidden="true"></i>
           </li>
          
          <li>
          <label for="hour" class="cpd-hour"><b>Hours</b></label>
          <input type="number" placeholder="5 Hours (max 15 min 1)" name="hours" maxlength="15" minlength="1" required><i class="fa fa-pencil-square-o a-pencil pencil1" aria-hidden="true"></i>
          </li>

          <li>
           <label for="sumaary" class="summary-area"><b>Summary</b></label>
           <textarea id="summary" name="summary" placeholder="About your log (max 350 min 20)" maxlength="350" minlength="20" required></textarea>
           </li>

           <li>
           <label for="notes" class="notes-area"><b>Notes</b></label>
           <textarea id="notes" name="notes" placeholder="Summery (max 350 min 20)" maxlength="350" minlength="20" required></textarea>
           </li>
 
          <li>
          <label for="" class="cpd-hour"><b>Tags</b></label>
          <input type="text" placeholder="Coding (max 35 min 3)" style="margin-left: 15px !important;width: 83% !important;" name="tags" class="tags" maxlength="35" minlength="3" required>
          </li>

        </ul>
        <div class="space text-left">
            <button class="btn btn-primary" type="submit" style="cursor:pointer;background-color: #1D9B75!important;">Add Log</button>
          </div>
        </form> 
        </div>

        </div>
      </div>
      
    </div>
  </div>


<!-- Modal -->
      <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <img src="images/financial1.jpg" alt="" srcset="" style="width:100%">
          <h4 class="modal-title modal-title1"><i class="fa fa-trophy"></i> Financial Markets - Level 1</h4>
        </div>
        <div class="modal-body">
     
        <div class="modal-list modal-list-form">
        <form method="post" name="UserAchivemant" id="UserAchivemant" action="{{url('add-user-achivement')}}" enctype="multipart/form-data">
        @csrf
        <ul>

            <li>
            <label for="NameOfAchivement" class="a-name"><b>Name</b></label>
            <input type="text" id="NameOfAchivement" name="NameOfAchivement" placeholder = "Financial Regulations 101(max 35 min 3)" maxlength="35" minlength="3" style="margin-left:50px" required>
            </li>

          <li>
          <label for="issued"><b>Issued</b></label>
          <input type="date" id="start-date" name="start-date" placeholder = "mm/dd/yyyy" required>
          </li>

            <li>
            <label for="expire"><b>Expires</b></label>
            <label class="switch">
            <input type="checkbox" name="expires" id="expires">
            <span class="slider round ronud1"></span>
            </label>
            </li>

            <li id="expDateId" style="display:none;">
            <label for="expDate"><b>Expires<br> Date</b></label>
            <input type="date" style="margin-left:40px" id="expDate" name="expDate" placeholder = "mm/dd/yyyy">
            </li>

            <li>
            <label for="issued-by" class="issued-by"><b>Issued by</b></label>
            <input type="text" placeholder="Coursera (Online) (max 35 min 3)" name="issuedBy" maxlength="35" minlength="3" required><a><i class="fa fa-pencil-square-o a-pencil" aria-hidden="true"></i></a>
           </li>

           <li>
           <label for="link-to-course"><b>Link to course</b></label>
           <input type="url" placeholder="www.coursera.com/fb37fh733f" name="course_url" required><i class="fa fa-link a-link" aria-hidden="true"></i>
          </li>
          <li>
          <label for="duration" class="duration"><b>Duration</b></label>
          <input type="number" placeholder="12 Hours(max 15)" name="duration" maxlength="15" style="margin-left:30px" required><i class="fa fa-pencil-square-o a-pencil" aria-hidden="true"></i>
          </li>
          <li>
          <label for="language" class="issued-by"><b>Language</b></label>
          <select name="language" id="select" required>
                    <option value="">Choose a Language</option>
                    <option value="english(uk)">English(UK)</option>
                    <option value="english(international)">English(International)</option>
                    <option value="japanese">Japanese</option>
          </select>
          </li>

           <li>
           <label for="credits"><b>Credits</b></label>
           <label class="switch">
            <input type="checkbox" name="credits_status" id="credits_status">
            <span class="slider round"></span>
            </label>
           </li>
          
          <li id="cratitsInpNum" style="display:none;">
          <label for="cratitsInp" class=""><b>Enter Credits</b></label>
          <input type="number" placeholder="4 or 6" maxlength="5" minlength="0" name="cratitsInp" id="cratitsInp" style="margin-left: 14px">
          </li>

          
          <li id="highLiLevelDiv" style="display:none;">
          <label for="hILiglevel" class=""><b>Enter Level</b></label>
          <input type="text" placeholder="1 to 8" name="hILiglevel" id="hILiglevel"><i class="fa fa-pencil-square-o a-pencil" aria-hidden="true"></i>
          </li>

          <li>
          <label for="achType" class="issued-by"><b>Achivement<br> Type</b></label>
          <select name="achType" id="achType" style="margin-left: 14px" required>
                    <option value="edu">Educational</option>
                    <option value="other">Other</option>
          </select>
          </li>

           <li>
           <label for="notes" class="notes-area"><b>Notes</b></label>
           <textarea placeholder="As part of my job training...(max 350 min 20)" maxlength="350" minlength="20" id="notes" name="notes" required></textarea>
            </li>
            <input type="text" hidden name="redirectId" value="1">
            <li>
            <label for="achivePosition"><b>Achivement Lavel/Position</b></label>
            <label class="switch">
            <input type="checkbox" name="achivePosition" id="achivePosition">
            <span class="slider round ronud1"></span>
            </label>
            </li>

            <input type="text" name="valofData" id="valofData" hidden>

            <li id="achivePositionVal" style="display:none;">
            <label for="achivePosition"></label>
            <select name="achivementName" id="achivementName" style="width: 100%;
    margin: -30px 0 0 0;">
            <option value="">-- Select Position --</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</opPPtion>
            <option value="5">5</option>
            <option value="6">6</option>
            </select>
            </li>

            <li>
            <label for="uploadCertificate"><b>Upload Certificate</b>
            <input type="file" name="acchiCertificate" id="acchiCertificate"></label>
            </li>         
        </ul>
        <div class="space text-left">
        <button tyle="submit" class="btn btn-primary" id="addAchivement" style="cursor:pointer;background-color: #1D9B75!important;">Add Achievement</button>

        </div>
     </form>
        </div>
        </div>
        
      </div>
      
    </div>
  </div>
    
<!-- Modal -->
  <!-- Modal -->
  <div class="modal fade" id="inviteModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content text-center">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <img src="images/invite.jpg" alt="">
          <h4 class="modal-title text-center">Spread the word and get a free career consultation</h4>
          <p class="text-center">Invite a friend of colleague to CMyQual and you both get a coaching session with our own career experts.</p>
        </div>
        <div class="modal-body">
        <div class="space text-center">
        <form method="post" action="{{url('sendInvite')}}">    
        <input type="text" name="email" placeholder="hello@gmail.com" style="height: 30px;
    border-radius: 0;
    box-shadow: none;
    background-color: #fff;
    border: 1px solid rgb(62 163 164 / 55%);
    padding: 0 10px;">  
        @csrf<br>
        <button type="submit" name="btnsendmail" value="Invite" style="background: #1D9B75!important;
    padding: 3px 70px;
    text-transform: capitalize;
    font-family: 'Lato' ,sans-serif!important;
    border: none;
    color: #fff;
    margin-top: 10px;">Invite</button>
        <!--<a href="#" class="btn btn-primary" type="button" style="cursor:pointer;"></a>-->
        </form>
        </div>
        <div class="modal-list">

        </div>
        </div>
      </div>
      
    </div>
  </div>

    <!-- ******************************************
    /END SITE
    ********************************************** -->

    <!-- ******************************************
    DEFAULT JAVASCRIPT FILES
    ********************************************** -->
    
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js'></script>
    <script src="{{asset('assets/js/all.js')}}"></script>
    
    <script src='https://cdnjs.cloudflare.com/ajax/libs/easy-pie-chart/2.1.6/jquery.easypiechart.min.js'></script>
    <script src="{{asset('assets/js/custom.js')}}"></script>
    <!---- Select 2 ---->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
    <script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
    <!------ end select 2-->
    
    <script type="text/javascript">
    $('.js-example-basic-multiple-achivement').select2();
    $('.js-example-basic-multiple-sharedLog').select2();
    $(function() {
    $('.chart').easyPieChart({
      size: 115,
      barColor: "#1D9B75",
      scaleLength: 0,
      lineWidth: 8,
      trackColor: "#cfd8dc",
      lineCap: "circle",
      animate: 2000,
    });
  });

$('#UserAchivemant').validate({
 errorPlacement: function(){
            return false;  // suppresses error message text
        }
});

    $('#cpd-log').validate({
    errorPlacement: function(){
            return false;  // suppresses error message text
        }
});

$('#addAchivement').on('click',function(){
if($('#valofData').val()=='1'){
alert('This Level Is Already Used');
return false;
}else{
return true;
}
});

$('#achivePosition').on('change',function(){
if($('#achivePosition').is(':checked')){

$('#achivePositionVal').show();
$('#achivementName').prop('required',true);

}else{
$('#achivePositionVal').hide();
$('#achivementName').prop('required',false);
$('#valofData').val('0');
}
});

$("#credits_status").on('change',function(){

 if($("#credits_status").is(':checked')){
  $('#cratitsInpNum').show();
  $('#cratitsInp').prop('required',true);
  }else{
  $('#cratitsInpNum').hide();
  $('#cratitsInp').prop('required',false);
  }
});

$("#expires").on('change',function(){

 if($("#expires").is(':checked')){
  $('#expDateId').show();
  $('#expDate').prop('required',true);
  }else{
  $('#expDateId').hide();
  $('#expDate').prop('required',false);
  }
});

$('#checkAchivmentLevel').on('change',function(){
$.ajax({
url:'{{url("check-achivement-level")}}',
method:'POST',
data:{level:$('#checkAchivmentLevel').val(),userId:$('#userId').val(),"_token":"{{csrf_token()}}"},
success:function(data){
if(data==1){
alert('Already User This Level');
$('#valofData').val('1');
}else{
$('#valofData').val('0');
}
}
});
});


    </script>
    
<script>
window.chartColors = {
  red: 'transparent',
  orange: 'tranparent',
//   yellow: 'rgb(255, 205, 86)',
  green: 'rgb(75, 192, 192)',
  blue: '#48B359',
//   purple: 'rgb(153, 102, 255)',
//   grey: 'rgb(231,233,237)'
};

var randomScalingFactor = function() {
  return (Math.random() > 0.5 ? 1.0 : 1.0) * Math.round(Math.random() * 25);
};

var line1 = [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), ];

var line2 = [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), ];

var MONTHS = ["1/3", "8/3", "15/3", "22/5"]; //"May", "June", "July", "August", "September", "October", "November", "December"
var config = {
  type: 'line',
  data: {
    labels: MONTHS,
    datasets: [{
      label: "",
      backgroundColor: window.chartColors.red,
      borderColor: window.chartColors.red,
      data: line1,
      fill: false,
    }, {
      label: "",
      fill: false,
      backgroundColor: window.chartColors.blue,
      borderColor: window.chartColors.blue,
      data: line2,
    }]
  },
  options: {
    responsive: true,
    title:{
      display:true,
      text:''
    },
    tooltips: {
      mode: 'index',
      intersect: false,
    },
   hover: {
      mode: 'nearest',
      intersect: true
    },
    scales: {
      xAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: ''
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
        },
      }]
    }
  }
};

var ctx = document.getElementById("canvas").getContext("2d");
var myLine = new Chart(ctx, config);

var data1 = [
  randomScalingFactor(),
  randomScalingFactor(),
];

// var data2 = [
//   randomScalingFactor(),
//   randomScalingFactor(),
// ];

var ctx = document.getElementById("chart-area").getContext("2d");
var myPie = new Chart(ctx, {
  type: 'pie',
  data: {
        labels: ["FTE", "FTC"],
    datasets: [{
      label: 'Dataset 1',
      data: data1,
      backgroundColor: [
        "",
        ""
      ],
      hoverBackgroundColor: [
        "",
        ""
      ],
      borderWidth: 5,
    }, {
      label: 'Dataset 2',
      data: data2,
      backgroundColor: [
        "",
        ""
      ],
      hoverBackgroundColor: [
        "",
        ""
      ],
      borderWidth: 5,
    }],
  },
  options: {
    title: {
      display: true,
      text: 'Employee Overview',
      fontStyle: 'bold',
      fontSize: 20
    }
  }
});

/*
$('a[href="#pie"]').on('shown.bs.tab', function(){
  myPie.update();
});
*/
</script>

<script>
window.chartColors = {
  red: 'transparent',
  orange: 'tranparent',
//   yellow: 'rgb(255, 205, 86)',
  green: 'rgb(75, 192, 192)',
  blue: '#48B359',
//   purple: 'rgb(153, 102, 255)',
//   grey: 'rgb(231,233,237)'
};

var randomScalingFactor = function() {
  return (Math.random() > 0.5 ? 1.0 : 1.0) * Math.round(Math.random() * 25);
};

var line1 = [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), ];

var line2 = [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), ];

var MONTHS = ["1/3", "8/3", "15/3", "22/5"]; //"May", "June", "July", "August", "September", "October", "November", "December"
var config = {
  type: 'line',
  data: {
    labels: MONTHS,
    datasets: [{
      label: "",
      backgroundColor: window.chartColors.red,
      borderColor: window.chartColors.red,
      data: line1,
      fill: false,
    }, {
      label: "",
      fill: false,
      backgroundColor: window.chartColors.blue,
      borderColor: window.chartColors.blue,
      data: line2,
    }]
  },
  options: {
    responsive: true,
    title:{
      display:true,
      text:''
    },
    tooltips: {
      mode: 'index',
      intersect: false,
    },
   hover: {
      mode: 'nearest',
      intersect: true
    },
    scales: {
      xAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: ''
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
        },
      }]
    }
  }
};

var ctx = document.getElementById("share-canvas").getContext("2d");
var myLine = new Chart(ctx, config);

var data1 = [
  randomScalingFactor(),
  randomScalingFactor(),
];

// var data2 = [
//   randomScalingFactor(),
//   randomScalingFactor(),
// ];

var ctx = document.getElementById("share-canvas").getContext("2d");
var myPie = new Chart(ctx, {
  type: 'pie',
  data: {
        labels: ["FTE", "FTC"],
    datasets: [{
      label: 'Dataset 1',
      data: data1,
      backgroundColor: [
        "",
        ""
      ],
      hoverBackgroundColor: [
        "",
        ""
      ],
      borderWidth: 5,
    }, {
      label: 'Dataset 2',
      data: data2,
      backgroundColor: [
        "",
        ""
      ],
      hoverBackgroundColor: [
        "",
        ""
      ],
      borderWidth: 5,
    }],
  },
  options: {
    title: {
      display: true,
      text: 'Employee Overview',
      fontStyle: 'bold',
      fontSize: 20
    }
  }
});
</script>
</body>
</html>