<!DOCTYPE html>
<html>
<head>
	<title> CPD Log PDF</title>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
<h1 style="text-align:center;">My CPD LOG</h1>
<table class="table bordered" border="1" align="center" style="padding-top:20px">
<tr><td>Title</td> : <td>{{$cpdLogsInfo->title}}</td></tr>	

<tr><td>Provider</td> : <td>{{$cpdLogsInfo->providers}}</td></tr>	

<tr><td>Stander</td> : <td>{{$cpdLogsInfo->stander}}</td></tr>	

<tr><td>Hours</td> : <td>{{$cpdLogsInfo->hours}}</td></tr>	

<tr><td>Tag</td> : <td>{{$cpdLogsInfo->tags}}</td></tr>	

<tr><td>Date</td> : <td>{{$cpdLogsInfo->date}}</td></tr>	

</table>
</body>
</html>