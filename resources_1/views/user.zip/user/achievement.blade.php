<!DOCTYPE html>
<html lang="en">


<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- SITE META -->
    <title>CMYQUAL</title>
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keywords" content="">

    <!-- FAVICONS -->
   
    <!-- BOOTSTRAP STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/bootstrap.min.css')}}">
    <!-- TEMPLATE STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/style.css')}}">
    <!-- RESPONSIVE STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/responsive.css')}}">
    <!-- COLORS STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/colors.css')}}">
    <!-- CUSTOM STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/custom.css')}}">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<style>
.tree-main.treee-main .tree3 {
    top: 42%;
    left: 170px!important;
}
.tree-main.treee-main .tree2 {
    top: 0%;
    left: 160px!important;
}
.tree-main.treee-main .tree4 {
    top: 0% !important;
}
.tree-main.treee-main .tree1 span {
    padding: 0px 0px 0 0px!important;
    top: 20px!important;
    right: 10px!important;
}
.tree-main.treee-main .tree5 {
    top: 42% !important;
    left: 58%;
}
@media(max-width:1600px)
{
    .tree3 {
    left: 250px!important;
}
.tree2 {
    left: 245px!important;
}
}
    html{scroll-behavior: smooth;}
    span.all-goal
    {
      font-weight: 600;
    }
    .goals-border
    {
      padding-bottom: 10px;
      padding-top: 10px;
    }
    .goals-border .add-new-box.add-new-box {
    margin-top: 0px;
}
.add-new-box span
{
  padding: 5px 13px;
}
.add-new-box
{
  height:30px;
}
.goal-box ul li
{
  padding:10px 15px;
}
li.goal-box-border img{max-width: 100%;}
.goal-box ul li
{
    width: 25%;
    min-height: 160px;
    display: flex;
    float: left;
    margin-bottom: 20px;
    margin-right: 15px!important;
}
.img-trophy
{
  position: absolute;
    z-index: 99;
    top: 10.5%;
    left: 9.95%;
    font-size: 30px;
    color: #fff;
}
.img-trophy2
{
  position: absolute;
    z-index: 99;
    top: 10.5%;
    left: 30.95%;
    font-size: 30px;
    color: #fff;
}
li.goal-box-border h4
{
  font-size: 15px!important;
  color: #111!important;
}
.goal-box.goal-box1 ul li.goal-box-border .icon .fa
{
  color: #48B359;
  display: block;
  font-size: 30px;
  text-align: center;
}
@media(min-width:1440px)
{
  .goal-box ul li {
    width: 24%;
    margin-bottom: 15px;
}
.goal-box ul li {
    padding: 10px 20px!important;
}
.img-trophy2
{
  left: 33.95%;
}
.img-mobile-msc , .img-mobile
{
  height:85px!important;
}
}
@media (min-width: 1600px)
{
.img-mobile-msc, .img-mobile {
    height: 105px!important;
}
}
@media(max-width:1024px)
{
  .change-career.change-career2.achievement {
    height: 330px;
}
.add-new-box
{
  width: 66%;
}
.goal-box ul li {
    width: 25%;
}

}
@media(max-width:768px)
{
  #my-profile
  {
    padding-top:40px;
  }
  li.goal-box-border img {
    max-width: 45%;
    margin-right: 10px;
}

.img-trophy
{
  top: 7.5%;
  left: 20.95%
}
.img-trophy2
{
  top: 28.5%;
    left: 20.95%;
}
  .goal-box ul.my li.goal-box-border {
    height: auto;
    width: 100%;
}
  .change-career.change-career2.achievement .col-lg-3.col-md-3.col-sm-12
  {
    width: 33.3333333333%;
    padding-left: 0;
  }
  .change-career.change-career2.achievement .col-lg-9.col-md-9.col-sm-12
  {
    width: 66%;
    padding-left: 0;
  }
  .goal-box ul li {
        width: 32.5%;
    }
}
@media(max-width:414px)
{
  .change-career.change-career2.achievement {
    height: auto;
}
.change-career.change-career2
{
  margin: 10px 0 0px 0;
}
.change-career.change-career2 h4 {
    font-size: 15px!important;
}
#my-profile {
    padding-top: 70px;
}
.change-career.change-career2.achievement .col-lg-3.col-md-3.col-sm-12 , .change-career.change-career2.achievement .col-lg-9.col-md-9.col-sm-12
{
  width:100%;
}
.goals-border
{
  margin-top:10px;
}
.goal-box ul.my li.goal-box-border
{
  width:100%;
}
li.goal-box-border img {
    max-width: 40%;
    margin-right: 10px;
}
.img-trophy
{
    top: 6.5%;
    left: 18.95%;
    font-size: 20px;
}
.img-trophy2
{
    top: 23.5%;
    left: 18.95%;
    font-size: 20px;
}

.add-new-box.add-new-box1
{
  width: 55%;
}
}
@media(max-width:375px)
{
  .change-career.change-career2.achievement
  {
    width: 113%;
    margin-left: -20px;
  }
  .tree-main.treee-main .tree4 {
    left: 68%;
}
.tree-main.treee-main .tree2
{
  left:-10px;
}
.tree-main.treee-main .tree3 {
    left: 0px;
}
}
@media(max-width:360px)
{
  .change-career.change-career2.achievement {
    width: 100%;
    margin-left: 0;
}
.tree-main.treee-main .tree2 {
    left: -30px;
}
.tree-main.treee-main .tree3 {
    left: -20px;
}
.tree-main.treee-main {
    margin-left: 3px;
}
.tree-main.treee-main .tree3 {
    left: -25px;
}
.tree-main.treee-main .tree2 span
{
  top: 34px;
}
.tree-main.treee-main .tree1 span
{
    top: 32px;
    right: 0px;
}
.tree-main.treee-main .tree4 span
{
    top: 35px;
    right: 3px
}
.tree-main.treee-main .tree6 span
{
    font-size: 10px!important;
    padding-top: 40px!important;
    padding-left: 20px;
}
.tree-main.treee-main .tree5 span {
    top: 40px;
    right: 5px;
}
}
.a-name b{
  padding-right:22px;
}
#achType
{
margin-left: 90px;
    margin-top: -45px;
    width: 82%;
    height: 35px;
    /* padding-top: 0; */
    display: inherit;
}
.goal-box-border.not-approved
{
  background: rgb(132 132 132 / 34%);
  border: none;
}
.goal-box-border.not-approved .close
{
    background: rgb(132 132 132 / 40%);
    opacity: 10;
    width: 35px;
    height: 25px;
    line-height: 25px;
    border-radius: 50%;
    color: #fff;
    font-size: 15px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition:0.4s;
}
.goal-box-border.not-approved .close:hover
{
  opacity: 0;
}
span.super-admin-span {
  display: none;
  transition:0.4s;
  text-align:center;
}

.goal-box-border.not-approved .close:hover + span.super-admin-span {
 
  display:block;
  position: absolute;
  background: #ffffff;
    transform: translate(10px, 40px);
    padding: 20px;
}
.expDate{
    margin: 5px 0 0px 50px;
    width: 83%;
    padding: 5px 10px 5px 10px;
    background-color: #fff;
    border: 1px solid rgb(62 163 164 / 55%);
     }
.error{
 border-color:#ef3f17cc !important;    
}     

</style>
<body class="dashboard-background leftmenu memberprofile">

    <!-- PRELOADER -->
    <!-- <div class="cssload-container">
        <div class="cssload-loader"></div>
    </div> -->
    <!-- end PRELOADER -->

    <!-- ******************************************
    START SITE HERE
    ********************************************** -->
         @include('user.sidebarStu') 
        <div id="wrapper">
        <!-- Sidebar -->
         @include('user.sidebar')
      
        <div id="page-content-wrapper">
            <a href="#menu-toggle" class="menuopener" id="menu-toggle"><i class="fa fa-bars"></i></a>
            <div class="demo-parallax parallax section looking-photo nopadbot achievement-bg" data-stellar-background-ratio="0.5">
                <div class="page-title section nobg">
                    <div class="container-fluid">
                        <div class="clearfix">
                            <div class="title-area pull-left">
                                <!-- <h2>My account</h2>   -->
                                <!---<small>Hello there, this is my profile.</small>--->
                            </div>
                            <!-- /.pull-right -->
                            <div class="pull-right hidden-xs">
                                <div class="bread">
                                    <ol class="breadcrumb">
                                        <li><a href="index.php"><i class="fa fa-home" aria-hidden="true"></i></a></li>
                                        <li><a href="my-profile.php">My Profile</a></li>
                                        <li><a href="achievement.php">Achievement</a></li>
                                        <!-- <li><a href="">Unfiled Organization</a></li> -->
                                    </ol>
                                </div>
                                <!-- end bread -->
                            </div>
                            <!-- /.pull-right -->
                        </div>
                        <!-- end clearfix -->
                    </div>
                </div>
                <!-- end page-title -->
            </div>

            <div class="section" id="my-profile">
                <div class="container-fluid">
                    <div class="row">
                    

                        <div class="col-md-12 col-sm-12">
                            <div class="about-widget clearfix">
                                <div class="widget-title">
                                    <!-- <h1 class="heading1">Goals</h1> -->
                                  
                                </div><!-- end title -->
                          
                                    <!-- <div class="col-lg-12">
                                    
                                    </div> -->
                                    <div class="col-lg-12">
                      <h4>Achievements</h4>
                      <p>Your qualifications, degrees, awards, and exam results.</p>
                    </div>
<div class="col-lg-12 col-md-12 col-sm-12">
   <div class="change-career change-career2 achievement">
   <h4><i class="fa fa-caret-down" aria-hidden="true"></i> Overview</h4>

<div class="col-lg-12 col-sm-12">
  <div class="col-lg-3 col-md-3 col-sm-12">
   <div class="overview-figma-icon">
     <h5 class="trophy"><i class="fa fa-trophy"></i>{{$totalCount}}</h5>
     <span>Achievements</span>
     <h5 class="exclamation"><i class="fa fa-exclamation-circle" aria-hidden="true"></i> 1</h5>
     <span>Expiring soon</span>
   </div>
  </div>
   <div class="next-step next-step1">
   <div class="col-lg-9 col-md-9 col-sm-12">

   <div class="tree-main treee-main">   
    
    <div class="tree1">
    <span>@if($levelOne[0]->achivementType=='edu')
    <i class="fa fa-graduation-cap" aria-hidden="true"></i>
    @elseif($levelOne[0]->achivementType=='other')
    <i class="fa fa-trophy" aria-hidden="true"></i>
    @else

    @endif

    {{$levelOne[0]->achivementName}}</span>
    </div>
  
    <div class="tree2">
    <span>@if($levelTwo[0]->achivementType=='edu')
    <i class="fa fa-graduation-cap" aria-hidden="true"></i>
    @elseif($levelTwo[0]->achivementType=='other')
    <i class="fa fa-trophy" aria-hidden="true"></i>
    @else
   
    @endif
    {{$levelTwo[0]->achivementName}}</span>
    </div>
  
    <div class="tree3">
    <span>@if($levelThree[0]->achivementType=='edu')
    <i class="fa fa-graduation-cap" aria-hidden="true"></i>
    @elseif($levelThree[0]->achivementType=='other')
    <i class="fa fa-trophy" aria-hidden="true"></i>
    @else
    @endif
    {{$levelThree[0]->achivementName}}</span>
    <span><i class="fa fa-trophy" aria-hidden="true"></i> Achievement 1</span>
    </div>
  
    <div class="tree4">
    <span>@if($levelFour[0]->achivementType=='edu')
    <i class="fa fa-graduation-cap" aria-hidden="true"></i>
    @elseif($levelFour[0]->achivementType=='other')
    <i class="fa fa-trophy" aria-hidden="true"></i>
    @else
    @endif
    {{$levelFour[0]->achivementName}}</span>
    </div>
  
    <div class="tree5">
    <span>@if($levelFive[0]->achivementType=='edu')
   <i class="fa fa-graduation-cap" aria-hidden="true"></i>
   @elseif($levelFive[0]->achivementType=='other')
   <i class="fa fa-trophy" aria-hidden="true"></i>
    @else
    
    @endif
    {{$levelFive[0]->achivementName}}</span>
    </div>

    <div class="tree6">
    <span>@if($levelSix[0]->achivementType=='edu')
    <i class="fa fa-graduation-cap" aria-hidden="true"></i>
    @elseif($levelSix[0]->achivementType=='other')
    <i class="fa fa-trophy" aria-hidden="true"></i>
    @else
    
    @endif{{$levelSix[0]->achivementName}}</span>
    </div>

    <div class="tree-root">
    </div>

  </div>

  
  

    </div>
</div>

   </div>
   </div>
   </div>
</div>
<div class="col-lg-12 goals-border">
<div class="col-lg-9 col-md-9 col-sm-6 col-xs-6">
<span class="all-goal">All Achievements</span>
</div>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
<div class="add-new-box add-new-box1">
    <span type="button" data-toggle="modal" data-target="#myModal" style="cursor:pointer;">+ Add New <i class="fa fa-angle-down" aria-hidden="true"></i></span>
</div>
</div>
</div>


<div class="col-lg-12 goal-box goal-box1 text-left">
    <ul class="my">
    @foreach($achivementInfo as $achivementInfoData)
    @if($achivementInfoData->adminAppStatus=='1')
      <li class="goal-box-border">
       <!-- <img src="{{asset('assets/images/coursera.jpg')}}" alt="" class="img-responsive"> -->
  
        <div class="icon">

  
@if($achivementInfoData->achivementType=='edu') 
       <i class="fa fa-graduation-cap" aria-hidden="true"></i>
@else
       <i class="fa fa-trophy"></i>
@endif     

        <h4>
        (Approved By Admin)  
        {{$achivementInfoData->achivementName}}
        </h4>
        <span>
         {{$achivementInfoData->Issued_by}}
        </span><br>
         <span class="three-days">@if($achivementInfoData->expires_date) 
         {{$achivementInfoData->expires_date}}
         @else @endif</span>
         <a href="javascript:void(0)" onclick="editAchivement({{$achivementInfoData->id}})"><span type="button">Edit</span></a>  
        </div>
        </li>
        @else

      <li class="goal-box-border not-approved">
        <button type="button" class="close" data-dismiss="modal">×</button>
        <span class="super-admin-span">not approved by super admin</span>
      <img src="asset('assets/images/coursera.jpg')" alt="" class="img-responsive img-mobile" style="display:none;height: 65px;">
    
        <div class="icon">
     @if($achivementInfoData->achivementType=='edu') 
       <i class="fa fa-graduation-cap" aria-hidden="true"></i>
@else
         <i class="fa fa-trophy"></i>
@endif
        <h4>
        (Not Approved By Admin) 
        {{$achivementInfoData->achivementName}}
        </h4>
        <span>
           {{$achivementInfoData->Issued_by}}
        </span><br>
         <span class="three-days">@if($achivementInfoData->expires_date) 
         {{$achivementInfoData->expires_date}}
         @else @endif</span>
        <a href="javascript:void(0)" onclick="editAchivement({{$achivementInfoData->id}})">Edit</a> 
        </div>
        </li>

    @endif
  @endforeach
    </ul>
</div>


    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <img src="images/financial1.jpg" alt="" srcset="" style="width:100%">
          <h4 class="modal-title modal-title1"><i class="fa fa-trophy"></i> Financial Markets - Level 1</h4>
        </div>
        
        <div class="modal-body">
     
        <div class="modal-list modal-list-form">
        <form method="post" name="UserAchivemant" id="UserAchivemant" action="{{url('add-user-achivement')}}" enctype="multipart/form-data">
        @csrf
        <ul>

            <li>
            <label for="NameOfAchivement" class="a-name"><b>Name</b></label>
            <input type="text" id="NameOfAchivement" name="NameOfAchivement" maxlength="35" minlength="3" placeholder = "Financial Regulations 101" required>
            </li>

          <li>
          <label for="issued"><b>Issued</b></label>
          <input type="date" id="start-date" name="start-date" placeholder = "mm/dd/yyyy" required>
          <input type="text" name="editId" id="editId"  hidden>
          </li>

            <li>
            <label for="expire"><b>Expires</b></label>
            <label class="switch">
            <input type="checkbox" name="expires" id="expires">
            <span class="slider round ronud1"></span>
            </label>
            </li>

            <li id="expDateId" style="display:none;">
            <label for="expDate"><b>Expires Date</b></label>
            <input type="date" id="expDate" name="expDate" placeholder = "mm/dd/yyyy" style="margin: 0px 0 0px 16px;width: 83%;padding: 5px 10px 5px 10px;background-color: #fff;border: 1px solid rgb(62 163 164 / 55%);">
            </li>

            <li>
            <label for="issued-by" class="issued-by"><b>Issued by</b></label>
            <input type="text" placeholder="Coursera (Online)" name="issuedBy" id="issuedBy" maxlength="35" minlength="3"  required><a><i class="fa fa-pencil-square-o a-pencil" aria-hidden="true"></i></a>
           </li>

           <li>
           <label for="link-to-course"><b>Link to course</b></label>
           <input type="url" placeholder="www.coursera.com/fb37fh733f" name="course_url" id="course_url" required><i class="fa fa-link a-link" aria-hidden="true"></i>
          </li>
          <li>
          <label for="duration" class="duration"><b>Duration</b></label>
          <input type="number" placeholder="12 Hours" name="duration" id="duration" maxlength="15" minlength="0" style="margin-left:30px" required><i class="fa fa-pencil-square-o a-pencil" aria-hidden="true"></i>
          </li>
          <li>
          <label for="language" class="issued-by"><b>Language</b></label>
          <select name="language" id="language" required>
                    <option value="">Choose a Language</option>
                    <option value="english(uk)">English(UK)</option>
                    <option value="english(international)">English(International)</option>
                    <option value="japanese">Japanese</option>
          </select>
          </li>

           <li>
           <label for="credits"><b>Credits</b></label>
           <label class="switch">
            <input type="checkbox" name="credits_status" id="credits_status">
            <span class="slider round"></span>
            </label>
           </li>
          
          <li id="cratitsInpNum" style="display:none;">
          <label for="cratitsInp" class=""><b>Enter Credits</b></label>
          <input type="number" placeholder="4 or 6" name="cratitsInp" style="margin: 6px 0 0px 11px;width: 83%;padding: 5px 10px 5px 10px;border: none;background: #fff;border: 1px solid rgb(62 163 164 / 55%);" id="cratitsInp"><i class="fa fa-pencil-square-o a-pencil" aria-hidden="true"></i>
          </li>

   
          <li>
          <label for="achType" class="issued-by"><b>Achivement<br> Type</b></label>
          <select name="achType" id="achType" required>
                    <option value="edu">Educational</option>
                    <option value="other">Other</option>
          </select>
          </li>

           <li>
           <label for="notes" class="notes-area"><b>Notes</b></label>
           <textarea placeholder="As part of my job training...min(20) max(350)" minlength="20"  maxlength="350" id="notes" name="notes" required></textarea>
            </li>

            <li>
            <label for="achivePosition"><b>Achivement Level</b></label>
            <label class="switch">
            <input type="checkbox" name="achivePosition" id="achivePosition">
            <span class="slider round ronud1"></span>
            </label>
            </li>

            <input type="text" name="valofData" id="valofData" hidden>

            <li id="achivePositionVal" style="display:none;">
            <label for="achivePosition"></label>
            <select name="achivementName" id="achivementName" style="width: 100%;
    margin: -30px 0 0 0;">
            <option value="">-- Select Position --</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</opPPtion>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            </select>
            </li>

            <li>
            <label for="uploadCertificate"><b>Upload Certificate</b>
            <input type="file" name="acchiCertificate" id="acchiCertificate"></label>
            </li>

         
        </ul>
        <div class="space text-left">
        <button tyle="submit" class="btn btn-primary" id="addAchivement" style="cursor:pointer;background-color: #1D9B75 !important">Add Achievement</button>

        </div>
     </form>
        </div>
        </div>

      </div>
      
    </div>
  </div>

<!-- Modal -->
<div class="modal fade" id="editModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
         
          <h4 class="modal-title modal-title1">Edit Achievement</h4>
        </div>
        <div class="modal-body">
     
        <div class="modal-list modal-list-form">

            <ul>
            <li>
            <label for="issued"><b>Issued</b></label>
            <input type="date" id="start-date" name="start-date" placeholder = "mm/dd/yyyy" required>
            </li>
            <li>
            <label for="expire"><b>Expires</b></label>
            <label class="switch">
            <input type="checkbox">
            <span class="slider round ronud1"></span>
            </label>
            </li>
            <li>
            <label for="issued-by" class="issued-by"><b>Issued by</b></label>
            <input type="text" placeholder="Coursera (Online)" name="issued-by" required><a><i class="fa fa-pencil-square-o a-pencil" aria-hidden="true"></i></a>
           </li>
           <li>
           <label for="link-to-course"><b>Link to course</b></label>
           <input type="url" placeholder="www.coursera.com/fb37fh733f" name="url" required><i class="fa fa-link a-link" aria-hidden="true"></i>
          </li>
          <li>
          <label for="duration" class="duration"><b>Duration</b></label>
          <input type="number" placeholder="12 Hours" name="duration" style="margin-left:30px" required><i class="fa fa-pencil-square-o a-pencil" aria-hidden="true"></i>
          </li>
          <li>
          <label for="language" class="issued-by"><b>Language</b></label>
          <select name="language" id="select" required>
                    <option value="">Choose a Language</option>
                    <option value="english(uk)">English(UK)</option>
                    <option value="english(international)">English(International)</option>
                    <option value="japanese">Japanese</option>
          </select>
          </li>
           
          <li>
          <label for="achType" class="issued-by"><b>Achivement Type</b></label>
          <select name="achType" id="achType" required>
                    <option value="edu">Educational</option>
                    <option value="other">Other</option>
          </select>
          </li>

           <li>
           <label for="credits"><b>Credits</b></label>
           <label class="switch">
            <input type="checkbox" name="credits">
            <span class="slider round"></span>
            </label>
           </li>

           <li>
           <label for="notes" class="notes-area"><b>Notes</b></label>
           <textarea placeholder="As part of my job training..." id="notes" name="notes">
  
           </textarea>
            </li>
            <li>
            </li>
            </ul>
       
        </div>
        </div>
        
      </div>
      
    </div>
  </div>

            <!-- end copyrights -->

        <!-- end page-content-wrapper -->
       
    </div>
    <!-- end wrapper -->
  
    <!-- ******************************************
    /END SITE
    ********************************************** -->

    <!-- ******************************************
    DEFAULT JAVASCRIPT FILES
    ********************************************** -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js'></script>
    <script src="js/all.js"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/easy-pie-chart/2.1.6/jquery.easypiechart.min.js'></script>
    <script src="{{asset('assets/js/custom.js')}}"></script>
    <script src="{{asset('assets/js/jquery.validate.min.js')}}"></script>
    <script>
     <script type="text/javascript">
$('.barra-nivel').each(function() {
  var valorLargura = $(this).data('nivel');
  var valorNivel = $(this).html("<span class='valor-nivel'>"+valorLargura+"</span>");
    $(this).animate({
        width: valorLargura
    });
});
</script>
    <script type="text/javascript">
    
    $(function(){

    $('.chart').easyPieChart({
      size: 115,
      barColor: "#fff",
      scaleLength: 0,
      lineWidth: 8,
      trackColor: "#3333",
      lineCap: "circle",
      animate: 2000,
    });
  });


$('#addAchivement').on('click',function(){
if($('#valofData').val()=='1'){
alert('This Level Is Already Used');
return false;
}else{
return true;
}
});

$('#achivePosition').on('change',function(){
if($('#achivePosition').is(':checked')){

$('#achivePositionVal').show();
$('#achivementName').prop('required',true);

}else{
$('#achivePositionVal').hide();
$('#achivementName').prop('required',false);
}
});

$("#credits_status").on('change',function(){

 if($("#credits_status").is(':checked')){
  $('#cratitsInpNum').show();
  $('#cratitsInp').prop('required',true);
  }else{
  $('#cratitsInpNum').hide();
  $('#cratitsInp').prop('required',false);
  }
});

$("#expires").on('change',function(){

 if($("#expires").is(':checked')){
  $('#expDateId').show();
  $('#expDate').prop('required',true);
  }else{
  $('#expDateId').hide();
  $('#expDate').prop('required',false);
  }
});

$('#checkAchivmentLevel').on('change',function(){
$.ajax({
url:'{{url("check-achivement-level")}}',
method:'POST',
data:{level:$('#checkAchivmentLevel').val(),userId:$('#userId').val(),"_token":"{{csrf_token()}}"},
success:function(data){
if(data==1){
alert('Already User This Level');
$('#valofData').val('1');
}else{
$('#valofData').val('0');
}
}
});
});

$('#UserAchivemant').validate({
 errorPlacement: function(){
            return false;  // suppresses error message text
        }
});

</script>

    
<script>
window.chartColors = {
  red: 'transparent',
  orange: 'tranparent',
//   yellow: 'rgb(255, 205, 86)',
  green: 'rgb(75, 192, 192)',
  blue: '#fff',
//   purple: 'rgb(153, 102, 255)',
//   grey: 'rgb(231,233,237)'
};

var randomScalingFactor = function() {
  return (Math.random() > 0.5 ? 1.0 : 1.0) * Math.round(Math.random() * 25);
};

var line1 = [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), ];

var line2 = [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), ];

var MONTHS = ["1/3", "8/3", "15/3", "22/5"]; //"May", "June", "July", "August", "September", "October", "November", "December"
var config = {
  type: 'line',
  data: {
    labels: MONTHS,
    datasets: [{
      label: "",
      backgroundColor: window.chartColors.red,
      borderColor: window.chartColors.red,
      data: line1,
      fill: false,
    }, {
      label: "",
      fill: false,
      backgroundColor: window.chartColors.blue,
      borderColor: window.chartColors.blue,
      data: line2,
    }]
  },
  options: {
    responsive: true,
    title:{
      display:true,
      text:''
    },
    tooltips: {
      mode: 'index',
      intersect: false,
    },
   hover: {
      mode: 'nearest',
      intersect: true
    },
    scales: {
      xAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: ''
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
        },
      }]
    }
  }
};

var ctx = document.getElementById("canvas").getContext("2d");
var myLine = new Chart(ctx, config);

var data1 = [
  randomScalingFactor(),
  randomScalingFactor(),
];

// var data2 = [
//   randomScalingFactor(),
//   randomScalingFactor(),
// ];

var ctx = document.getElementById("chart-area").getContext("2d");
var myPie = new Chart(ctx, {
  type: 'pie',
  data: {
        labels: ["FTE", "FTC"],
    datasets: [{
      label: 'Dataset 1',
      data: data1,
      backgroundColor: [
        "",
        ""
      ],
      hoverBackgroundColor: [
        "",
        ""
      ],
      borderWidth: 5,
    }, {
      label: 'Dataset 2',
      data: data2,
      backgroundColor: [
        "",
        ""
      ],
      hoverBackgroundColor: [
        "",
        ""
      ],
      borderWidth: 5,
    }],
  },
  options: {
    title: {
      display: true,
      text: 'Employee Overview',
      fontStyle: 'bold',
      fontSize: 20
    }
  }
});

/*
$('a[href="#pie"]').on('shown.bs.tab', function(){
  myPie.update();
});
*/
function editAchivement(id){
    
$.ajax({
url:'{{url('editStudentAchivement')}}',
method:'POST',
data:{id:id,'_token':'{{csrf_token()}}'},
success:function(data){
console.log(data);    
$('#myModal').modal('show');
$('#NameOfAchivement').val(data.title);
$('#start-date').val(data.Issued);

$('#course_url').val(data.providers);

$('#issuedBy').val(data.Issued_by);

$('#duration').val(data.duration);

$('#notes').val(data.notes);

$('#editId').val(data.id);

$('#language').val(data.language);

$('#course_url').val(data.link_to_course);

}
})
}
</script>
</body>


</html>