<!DOCTYPE html>
<html lang="en">


<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- SITE META -->
    <title>CMYQUAL</title>
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keywords" content="">

    <!-- FAVICONS -->
   
    <!-- BOOTSTRAP STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/bootstrap.min.css')}}">
    <!-- TEMPLATE STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/style.css')}}">
    <!-- RESPONSIVE STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/responsive.css')}}">
    <!-- COLORS STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/colors.css')}}">
    <!-- CUSTOM STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/custom.css')}}">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<style>
.next-step ul li
{
    padding: 0 15px 0 0px;
}
.modal-dialog {
    width: 800px;
}
    html{scroll-behavior: smooth;}
    /*@media(min-width:1440px)*/
    /*{*/
    /*  body.leftmenu #page-content-wrapper*/
    /*{*/
    /*  height:820px;*/
    /*}*/
    /*}*/
    /*@media(min-width:1600px)*/
    /*{*/
    /*  body.leftmenu #page-content-wrapper*/
    /*{*/
    /*  height:1000px;*/
    /*}*/
    /*}*/

    @media(max-width:768px)
    {
     
#my-profile p
{
  margin-bottom:30px;
}
}
@media(max-width:414px)
{
  #my-profile
  {
    padding-top:40px;
  }
  .new-figma-goal-page p {
    padding-left: 40%;
    font-size: 13px!important;
}
.next-step span {
    padding-top: 5px;
}
.chart.chart1 span {
    margin-left: -64%;
}
.goal-box ul li
{
  height:120px;
}
}
</style>
<body class="dashboard-background leftmenu memberprofile">

    <!-- PRELOADER -->
    <!-- <div class="cssload-container">
        <div class="cssload-loader"></div>
    </div> -->
    <!-- end PRELOADER -->

    <!-- ******************************************
    START SITE HERE
    ********************************************** -->
      @include('user.sidebarStu') 
    <div id="wrapper">
      @include('user.sidebar')
     
        <div id="page-content-wrapper">
            <a href="#menu-toggle" class="menuopener" id="menu-toggle"><i class="fa fa-bars"></i></a>
            <div class="demo-parallax parallax section looking-photo nopadbot goal-bg" data-stellar-background-ratio="0.5">
                <div class="page-title section nobg">
                    <div class="container-fluid">
                        <div class="clearfix">
                            <div class="title-area pull-left">
                                <!-- <h2>My account</h2>   -->
                                <!---<small>Hello there, this is my profile.</small>--->
                            </div>
                            <!-- /.pull-right -->
                            <div class="pull-right hidden-xs">
                                <div class="bread">
                                    <ol class="breadcrumb">
                                        <li><a href="index.php"><i class="fa fa-home" aria-hidden="true"></i></a></li>
                                        <li><a href="my-profile.php">My Profile</a></li>
                                        <li><a href="goal.php">Goals</a></li>
                                        <!-- <li><a href="">Unfiled Organization</a></li> -->
                                    </ol>
                                </div>
                                <!-- end bread -->
                            </div>
                            <!-- /.pull-right -->
                        </div>
                        <!-- end clearfix -->
                    </div>
                </div>
                <!-- end page-title -->
            </div>

            <div class="section" id="my-profile">
                <div class="container-fluid">
                    <div class="row">
                    <div class="col-lg-12">
                      <h4>Goals</h4>
                      <p>Track your progress towards the goals you choose</p>
                    </div>

                        <div class="col-md-12 col-sm-12">
                            <div class="about-widget clearfix">
                                <div class="widget-title">
                                    <!-- <h1 class="heading1">Goals</h1> -->
                                  
                                </div><!-- end title -->
                          
                                    <!-- <div class="col-lg-12">
                                    
                                    </div> -->
<div class="col-lg-12 col-md-12 col-sm-12 new-figma-goal-page">
   <div class="change-career change-career2 goal">
   <div class="col-lg-5 col-md-5 col-sm-12">
   <div class="next-step">
   <h4>Your current goal</h4>
   <span>Next Step:</span>
   <h4>Attend a Teacher Training Course </h4>
   <span class="ellipse">
   <i class="fa fa-ellipsis-h" aria-hidden="true"></i>
   </span>
   <div class="col-lg-12">
   <ul>
   <li>
   <span><i class="fa fa-check" aria-hidden="true"></i> Completed</span>
   </li>
   <li class="skip">
   <span><i class="fa fa-step-forward" aria-hidden="true"></i> Skip</span>
   </li>
   <li class="skip">
   <span> See all <i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
   </li>
   </ul>
   </div>
   </div>
   </div>
   <div class="col-lg-7 col-md-7 col-sm-12">
   <div class="box text-center">
    <div class="chart chart1" data-percent="30" data-scale-color="#CED6DC"><span>16% - Complete</span><canvas height="160" width="160"></canvas></div>
   </div>
   <p>
             {{$quots['quote']}}
     <span>- {{$quots['by']}}</span>
   </p>
   </div>
  
   </div>
</div>
<div class="col-lg-12 goals-border">
<div class="col-lg-9 col-md-9 col-sm-6 col-xs-6">
<span class="all-goal">All Goals</span>
</div>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
<div class="add-new-box add-new-box1">
    <span type="button" data-toggle="modal" data-target="#myModal" style="cursor:pointer;">+ Add New <i class="fa fa-angle-down" aria-hidden="true"></i></span>
</div>
</div>
</div>

  <div class="col-lg-12 goal-box">
    <ul>
    @foreach($goalOfStudent as $goalOfStudentData)
        <li class="goal-box-border">
        <div class="icon">
        <i class="fa fa-bullseye" aria-hidden="true"></i>
        <div class="new-chart" data-percent="20" data-scale-color="#CED6DC"><canvas height="10" width="10"></canvas><canvas height="5" width="5"></canvas><canvas height="115" width="115"></canvas></div>
        <h4>
          {{$goalOfStudentData->goal_name}}
        </h4>
        <span>
        Paused
        </span>
        </div>  
        </li>
    @endforeach
    </ul>
   </div>

    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Change Careers</h4>
          <span> <i class="fa fa-bullseye" aria-hidden="true"></i> Began 3 Weeks ago . Ongoing</span>
        </div>
        <div class="modal-body">
        <div class="barras">
        <div class="barra">
        <span>3/9</span>
        <div class="barra-nivel" data-nivel="30%"></div>
        </div>
        </div>
        <form method="post" action="{{url('add-student-goal')}}">
        <div class="modal-list">
          @csrf
        <ul>
        @foreach($goals as $allGoalsData)
            <li>
            <input type="checkbox" name="goalOfStu[]" value="{{$allGoalsData->id}}">
            {{$allGoalsData->goal_name}} 
            </li>
        @endforeach 

        </ul>
        <div class="space text-left">
        <!--    <a href="#"  type="button" data-toggle="modal" data-target="#submitModal" style="cursor:pointer;">Submit</a> -->
        <button class="btn btn-primary" type="submit" style="cursor:pointer;background-color: #1D9B75 !important">Submit</button>
        </div>
</form>
        </div>
        </div>
        
      </div>
      
    </div>
  </div>
  <div class="modal fade" id="submitModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header text-center">
      
         <button type="button" class="back"><a href=""><i class="fa fa-angle-left" aria-hidden="true"></i> Back</a></button>
        
          <div class="col-lg-12 text-center">
            <img src="images/success-goal.jpg" alt="">
          </div>
          <h4 class="modal-title">Woohoo, you completed your goal!</h4>
          <p class="text-center">You pushed through and the hard work paid off. Take a moment to bask in your glory.You earned this!</p>
        <div class="col-lg-12">
          <span class="span1">4 <br>Weeks to Complete</span>
          <span class="span2">7 <br> Steps Completed</span>
          <div class="form-group">
                            <input type="checkbox" id="agree">
                            <label for="agree">I am happy fo CMYQUAL to share</label>
         </div>
        </div>
    
        </div>
        <div class="modal-body">
        <div class="space text-center">
        <a href="#" class="btn btn-primary share-btn">Share <i class="fa fa-share-alt" aria-hidden="true"></i></a>
        <a href="goal.php" class="btn btn-primary">Go Back <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
        </a>
        </div>
        </div>
        </div>
        
      </div>
      
    </div>
  </div>


            <!-- end copyrights -->

        <!-- end page-content-wrapper -->
       
    </div>
    <!-- end wrapper -->
  
    <!-- ******************************************
    /END SITE
    ********************************************** -->

    <!-- ******************************************
    DEFAULT JAVASCRIPT FILES
    ********************************************** -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js'></script>
    <script src="{{asset('assets/js/all.js')}}"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/easy-pie-chart/2.1.6/jquery.easypiechart.min.js'></script>
    <script src="{{asset('assets/js/custom.js')}}"></script>

<script type="text/javascript">
$('.barra-nivel').each(function() {
  var valorLargura = $(this).data('nivel');
  var valorNivel = $(this).html("<span class='valor-nivel'>"+valorLargura+"</span>");
    $(this).animate({
        width: valorLargura
    });
});
</script>
    <script type="text/javascript">
    
    $(function() {
    $('.chart').easyPieChart({
      size: 115,
      barColor: "#1D9B75",
      scaleLength: 0,
      lineWidth: 8,
      trackColor: "#cfd8dc",
      lineCap: "circle",
      animate: 2000,
    });
  });
    </script>
    <script type="text/javascript">
    
    $(function() {
    $('new-chart').easyPieChart({
      size: 115,
      barColor: "#1D9B75",
      scaleLength: 0,
      lineWidth: 8,
      trackColor: "#cfd8dc",
      lineCap: "circle",
      animate: 2000,
    });
  });
    </script>
<script>
window.chartColors = {
  red: 'transparent',
  orange: 'tranparent',
//   yellow: 'rgb(255, 205, 86)',
  green: 'rgb(75, 192, 192)',
  blue: '#fff',
//   purple: 'rgb(153, 102, 255)',
//   grey: 'rgb(231,233,237)'
};

var randomScalingFactor = function() {
  return (Math.random() > 0.5 ? 1.0 : 1.0) * Math.round(Math.random() * 25);
};

var line1 = [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), ];

var line2 = [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), ];

var MONTHS = ["1/3", "8/3", "15/3", "22/5"]; //"May", "June", "July", "August", "September", "October", "November", "December"
var config = {
  type: 'line',
  data: {
    labels: MONTHS,
    datasets: [{
      label: "",
      backgroundColor: window.chartColors.red,
      borderColor: window.chartColors.red,
      data: line1,
      fill: false,
    }, {
      label: "",
      fill: false,
      backgroundColor: window.chartColors.blue,
      borderColor: window.chartColors.blue,
      data: line2,
    }]
  },
  options: {
    responsive: true,
    title:{
      display:true,
      text:''
    },
    tooltips: {
      mode: 'index',
      intersect: false,
    },
   hover: {
      mode: 'nearest',
      intersect: true
    },
    scales: {
      xAxes: [{
        display: true,
        scaleLabel: {
          display: true,
          labelString: ''
        }
      }],
      yAxes: [{
        display: true,
        scaleLabel: {
          display: true,
        },
      }]
    }
  }
};

var ctx = document.getElementById("canvas").getContext("2d");
var myLine = new Chart(ctx, config);

var data1 = [
  randomScalingFactor(),
  randomScalingFactor(),
];

// var data2 = [
//   randomScalingFactor(),
//   randomScalingFactor(),
// ];

var ctx = document.getElementById("chart-area").getContext("2d");
var myPie = new Chart(ctx, {
  type: 'pie',
  data: {
        labels: ["FTE", "FTC"],
    datasets: [{
      label: 'Dataset 1',
      data: data1,
      backgroundColor: [
        "",
        ""
      ],
      hoverBackgroundColor: [
        "",
        ""
      ],
      borderWidth: 5,
    }, {
      label: 'Dataset 2',
      data: data2,
      backgroundColor: [
        "",
        ""
      ],
      hoverBackgroundColor: [
        "",
        ""
      ],
      borderWidth: 5,
    }],
  },
  options: {
    title: {
      display: true,
      text: 'Employee Overview',
      fontStyle: 'bold',
      fontSize: 20
    }
  }
});

/*
$('a[href="#pie"]').on('shown.bs.tab', function(){
  myPie.update();
});
*/
</script>
</body>


</html>