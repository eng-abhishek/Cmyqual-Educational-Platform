<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<header class="header normal-header" data-spy="affix" data-offset-top="197">
            <div class="container">
                <nav class="navbar navbar-default yamm">
                    <div class="container-full">
                        <div class="navbar-header">
                          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" href="{{url('')}}"><img src="{{asset('assets/images/cmyqual-logo-header.png')}}"></a>
                        </div>
                        <!-- end navbar header -->

                        <div id="navbar" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="{{url('learners')}}">Learners</a></li> 
                                <li><a href="{{url('employers')}}">Employers</a></li>
                                <li><a href="{{url('associations')}}">Associations</a></li>
                                <li><a href="{{url('learning-institutions')}}">Learning institutions</a></li>
                                <li><a href="{{url('online-learning-partners')}}">Online learning Partners</a></li>
                              
                                 <li class="dropdown normal-menu has-submenu mobile-get-started-desktop">
                                    <a href="{{url('get-started')}}">Get Started</a><!--class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"---->

                                 </li>
                   <div class="sign-in-main2">
                               <!-- <div> -->
                                <li class="btn btn-default sign-in-btn2"><a title="sign in" href="javascript:void(0);">Sign In</a></li><!---mobile-sign-in-desktop--->
                                <div class="sign-in-dropdown-content2">

                                <a href="{{route('user-login')}}">Life Long Learners</a>
                                <a href="{{url('employer/login')}}">Employers</a>
                                <a href="{{url('partner/login')}}">Learning Partners</a>
                                
                               </div>
                             
                               <!-- </div> -->
</div>
                             </ul>
                         
                            <ul class="nav navbar-nav navbar-right" style="position: absolute;right: 0;">
                                <div class="dropdown2">
                                
                                <li class="dropbtn btn btn-default get-start-btn">
                                    <a title="Get Started" href="{{url('get-started')}}">Get Started</a>
                                </li>
                     
                              <div class="sign-in-main">
                                <li class="btn btn-default sign-in-btn"><a title="sign in" href="javascript:void(0);">Sign In</a></li><!---mobile-sign-in-desktop--->
                                <div class="sign-in-dropdown-content">

                                <a href="{{route('user-login')}}">Life Long Learners</a>
                                <a href="{{url('employer/login')}}">Employers</a>
                                <a href="{{url('partner/login')}}">Learning Partners</a>
                                
                               </div>
                             
                               </div>
                         
                                
                            </ul>
                            </div>
                            <!-- end dropdown -->
                        </div>
                        <!--/.nav-collapse -->
                    </div>
                    <!--/.container-fluid -->
                </nav>
                <!-- end nav -->
            </div>
            <!-- end container -->
        </header>
        <!-- end header -->